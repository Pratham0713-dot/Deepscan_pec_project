import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ScanInput } from './components/ScanInput';
import { ScoreGauge } from './components/ScoreGauge';
import { SentenceHeatmap } from './components/SentenceHeatmap';
import { LinguisticTelemetry } from './components/LinguisticTelemetry';
import { TropesInspector } from './components/TropesInspector';
import { HumanizerStudio } from './components/HumanizerStudio';
import { AuditCertificate } from './components/AuditCertificate';
import { CompareView } from './components/CompareView';
import { HistoryModal } from './components/HistoryModal';
import { ImageForensicsView } from './components/ImageForensicsView';
import { AudioForensicsView } from './components/AudioForensicsView';
import { DocumentForensicsView } from './components/DocumentForensicsView';
import {
  AnalysisResult,
  ScanMode,
  ScanHistoryItem,
  ForensicModality,
  ImageAnalysisResult,
  AudioAnalysisResult,
  DocumentAnalysisResult,
} from './types';
import {
  ShieldCheck,
  FileSearch,
  Activity,
  Layers,
  Sparkles,
  FileCheck,
  Zap,
  Fingerprint,
  Waves,
  Eye,
  AlertTriangle,
  RefreshCw,
  Cpu,
  Image as ImageIcon,
  Mic,
  BookOpen,
  FileText,
} from 'lucide-react';

export default function App() {
  const [activeModality, setActiveModality] = useState<ForensicModality>('text');
  const [text, setText] = useState<string>('');
  const [mode, setMode] = useState<ScanMode>('general');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<AnalysisResult | null>(null);
  const [activeTab, setActiveTab] = useState<'heatmap' | 'telemetry' | 'tropes' | 'humanizer' | 'certificate'>('heatmap');
  const [isCompareMode, setIsCompareMode] = useState<boolean>(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [history, setHistory] = useState<ScanHistoryItem[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load history from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('deepscan_history');
      if (saved) {
        setHistory(JSON.parse(saved));
      }
    } catch (e) {
      console.warn('Failed to load scan history:', e);
    }
  }, []);

  // Save history helper
  const saveToHistory = (item: ScanHistoryItem) => {
    try {
      const updated = [item, ...history.filter((h) => h.id !== item.id)].slice(0, 30);
      setHistory(updated);
      localStorage.setItem('deepscan_history', JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to save scan to history:', e);
    }
  };

  const handleClearHistory = () => {
    setHistory([]);
    localStorage.removeItem('deepscan_history');
  };

  // Text Scan Handler
  const handleRunScan = async (overrideText?: string) => {
    const textToScan = (overrideText ?? text).trim();
    if (!textToScan) {
      setErrorMessage('Please enter or paste text to analyze.');
      return;
    }

    setIsScanning(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToScan, mode }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || 'DeepScan engine error. Please check server status.');
      }

      const data = await res.json();
      const newResult: AnalysisResult = {
        ...data,
        id: `scan-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        timestamp: new Date().toISOString(),
        text: textToScan,
        mode,
      };

      setScanResult(newResult);

      const words = textToScan.split(/\s+/).filter(Boolean);
      saveToHistory({
        id: newResult.id,
        timestamp: newResult.timestamp,
        modality: 'text',
        titleSnippet: words.slice(0, 10).join(' ') + (words.length > 10 ? '...' : ''),
        overallAiProbability: newResult.overallAiProbability,
        verdict: newResult.verdict,
        textResult: newResult,
      });
    } catch (err: any) {
      console.error('Scan error:', err);
      setErrorMessage(err.message || 'An unexpected error occurred while analyzing the text.');
    } finally {
      setIsScanning(false);
    }
  };

  // Replace a specific sentence in the active text and re-trigger scan
  const handleApplySentenceReplacement = (oldText: string, newText: string) => {
    const updated = text.replace(oldText, newText);
    setText(updated);
    handleRunScan(updated);
  };

  // Image history saver
  const handleSaveImageResult = (imgRes: ImageAnalysisResult) => {
    saveToHistory({
      id: imgRes.id,
      timestamp: imgRes.timestamp,
      modality: 'image',
      titleSnippet: imgRes.imageName,
      overallAiProbability: imgRes.overallAiProbability,
      verdict: imgRes.verdict,
      imageResult: imgRes,
    });
  };

  // Audio history saver
  const handleSaveAudioResult = (audRes: AudioAnalysisResult) => {
    saveToHistory({
      id: audRes.id,
      timestamp: audRes.timestamp,
      modality: 'audio',
      titleSnippet: audRes.audioName,
      overallAiProbability: audRes.overallAiProbability,
      verdict: audRes.verdict,
      audioResult: audRes,
    });
  };

  // Doc history saver
  const handleSaveDocResult = (docRes: DocumentAnalysisResult) => {
    saveToHistory({
      id: docRes.id,
      timestamp: docRes.timestamp,
      modality: 'docs',
      titleSnippet: docRes.documentName,
      overallAiProbability: docRes.overallAiProbability,
      verdict: docRes.verdict,
      docResult: docRes,
    });
  };

  // Reset to initial clean state
  const handleReset = () => {
    setText('');
    setScanResult(null);
    setErrorMessage(null);
    setIsCompareMode(false);
  };

  return (
    <div className="min-h-screen bg-[#080b11] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Header */}
      <Header
        activeModality={activeModality}
        onChangeModality={(m) => {
          setActiveModality(m);
          setIsCompareMode(false);
        }}
        onOpenHistory={() => setIsHistoryOpen(true)}
        onOpenCompare={() => setIsCompareMode(!isCompareMode)}
        isCompareMode={isCompareMode}
        historyCount={history.length}
        onReset={handleReset}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Compare Mode View */}
        {isCompareMode ? (
          <CompareView onClose={() => setIsCompareMode(false)} />
        ) : activeModality === 'image' ? (
          /* Image Forensics Field */
          <ImageForensicsView onSaveToHistory={handleSaveImageResult} />
        ) : activeModality === 'audio' ? (
          /* Audio / Voice Forensics Field */
          <AudioForensicsView onSaveToHistory={handleSaveAudioResult} />
        ) : activeModality === 'docs' ? (
          /* Document Forensics Field */
          <DocumentForensicsView onSaveToHistory={handleSaveDocResult} />
        ) : (
          /* Text Forensics Field (Default) */
          <>
            {/* Hero / Introduction Header (only if no scan yet) */}
            {!scanResult && !isScanning && (
              <div className="text-center space-y-3 max-w-3xl mx-auto pt-2 pb-4">
                <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono">
                  <Cpu className="w-3.5 h-3.5" />
                  <span>Multimodal Neural Forensics: Text • Image • Audio • Docs</span>
                </div>
                <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white">
                  Detect AI-Generated Content with{' '}
                  <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400 bg-clip-text text-transparent">
                    Forensic Precision
                  </span>
                </h1>
                <p className="text-sm sm:text-base text-slate-400 max-w-2xl mx-auto leading-relaxed">
                  DeepScan AI inspects sentence perplexity, burstiness cadences, and synthetic n-gram
                  fingerprints to separate machine-generated prose from organic human thought.
                </p>
              </div>
            )}

            {/* Error Banner */}
            {errorMessage && (
              <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Scan Input Box */}
            <ScanInput
              text={text}
              onChangeText={setText}
              onScan={() => handleRunScan()}
              isScanning={isScanning}
              mode={mode}
              onChangeMode={setMode}
            />

            {/* Scanning In-Progress Indicator */}
            {isScanning && (
              <div className="cyber-card rounded-2xl p-8 bg-slate-900/60 border border-cyan-500/30 text-center space-y-4">
                <div className="relative w-16 h-16 mx-auto">
                  <div className="absolute inset-0 rounded-full border-2 border-cyan-500/20 border-t-cyan-400 animate-spin" />
                  <div
                    className="absolute inset-2 rounded-full border-2 border-sky-400/20 border-b-sky-400 animate-spin"
                    style={{ animationDirection: 'reverse' }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Fingerprint className="w-6 h-6 text-cyan-400 animate-pulse" />
                  </div>
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-100">Deconstructing Text Topology</h3>
                  <p className="text-xs text-slate-400 max-w-md mx-auto mt-1 font-mono">
                    Measuring vocabulary entropy, checking burstiness variation across clauses, and scanning 40+ known synthetic n-gram tropes...
                  </p>
                </div>
              </div>
            )}

            {/* Forensic Inspection Dashboard (Shown when results are ready) */}
            {scanResult && !isScanning && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
                {/* Primary Score Dial & Verdict Header */}
                <ScoreGauge result={scanResult} />

                {/* Sub-Navigation Tabs */}
                <div className="border-b border-slate-800">
                  <div className="flex items-center space-x-2 overflow-x-auto pb-px">
                    <button
                      onClick={() => setActiveTab('heatmap')}
                      className={`flex items-center space-x-2 px-4 py-3 text-xs sm:text-sm font-semibold border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                        activeTab === 'heatmap'
                          ? 'border-cyan-400 text-cyan-300 bg-cyan-500/5'
                          : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
                      }`}
                    >
                      <Eye className="w-4 h-4" />
                      <span>Sentence Heatmap</span>
                      <span className="px-1.5 py-0.2 rounded-full bg-slate-800 text-[10px] font-mono text-slate-300">
                        {scanResult.sentences.length}
                      </span>
                    </button>

                    <button
                      onClick={() => setActiveTab('telemetry')}
                      className={`flex items-center space-x-2 px-4 py-3 text-xs sm:text-sm font-semibold border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                        activeTab === 'telemetry'
                          ? 'border-cyan-400 text-cyan-300 bg-cyan-500/5'
                          : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
                      }`}
                    >
                      <Waves className="w-4 h-4" />
                      <span>Perplexity & Burstiness</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('tropes')}
                      className={`flex items-center space-x-2 px-4 py-3 text-xs sm:text-sm font-semibold border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                        activeTab === 'tropes'
                          ? 'border-cyan-400 text-cyan-300 bg-cyan-500/5'
                          : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
                      }`}
                    >
                      <Layers className="w-4 h-4" />
                      <span>AI Tropes & Clichés</span>
                      {scanResult.detectedAiTropes.length > 0 && (
                        <span className="px-1.5 py-0.2 rounded-full bg-rose-500/20 text-rose-300 text-[10px] font-mono border border-rose-500/30">
                          {scanResult.detectedAiTropes.length}
                        </span>
                      )}
                    </button>

                    <button
                      onClick={() => setActiveTab('humanizer')}
                      className={`flex items-center space-x-2 px-4 py-3 text-xs sm:text-sm font-semibold border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                        activeTab === 'humanizer'
                          ? 'border-emerald-400 text-emerald-300 bg-emerald-500/5'
                          : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
                      }`}
                    >
                      <Sparkles className="w-4 h-4 text-emerald-400" />
                      <span>Humanizer Studio</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('certificate')}
                      className={`flex items-center space-x-2 px-4 py-3 text-xs sm:text-sm font-semibold border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                        activeTab === 'certificate'
                          ? 'border-cyan-400 text-cyan-300 bg-cyan-500/5'
                          : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-700'
                      }`}
                    >
                      <FileCheck className="w-4 h-4" />
                      <span>Audit Certificate</span>
                    </button>
                  </div>
                </div>

                {/* Active Tab Panels */}
                <div>
                  {activeTab === 'heatmap' && (
                    <SentenceHeatmap
                      sentences={scanResult.sentences}
                      onApplySentenceReplacement={handleApplySentenceReplacement}
                    />
                  )}

                  {activeTab === 'telemetry' && (
                    <LinguisticTelemetry
                      metrics={scanResult.metrics}
                      styleAnalysis={scanResult.writingStyleAnalysis}
                      algorithmicStats={scanResult.algorithmicStats}
                    />
                  )}

                  {activeTab === 'tropes' && (
                    <TropesInspector
                      tropes={scanResult.detectedAiTropes}
                      recommendations={scanResult.actionableRecommendations}
                    />
                  )}

                  {activeTab === 'humanizer' && (
                    <HumanizerStudio
                      originalText={scanResult.text}
                      onScanNewText={(newText) => {
                        setText(newText);
                        handleRunScan(newText);
                        setActiveTab('heatmap');
                      }}
                    />
                  )}

                  {activeTab === 'certificate' && <AuditCertificate result={scanResult} />}
                </div>
              </div>
            )}

            {/* Feature Highlights Grid (when no scan is active) */}
            {!scanResult && !isScanning && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
                <div className="cyber-card rounded-2xl p-5 bg-slate-900/40 border border-slate-800/80 space-y-2">
                  <div className="w-9 h-9 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/20">
                    <Fingerprint className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-slate-100">Perplexity N-Gram Tracking</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Evaluates vocabulary unexpectedness. AI writes along deterministic probability
                    paths, whereas authentic human authors naturally integrate rare phrasing and colloquialisms.
                  </p>
                </div>

                <div className="cyber-card rounded-2xl p-5 bg-slate-900/40 border border-slate-800/80 space-y-2">
                  <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center border border-indigo-500/20">
                    <Waves className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-slate-100">Burstiness Cadence Waveform</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Measures rhythmic variance across sentences. Generative models produce uniform 18-24 word
                    monotonies, while humans oscillate dramatically from punchy fragments to rich, complex thoughts.
                  </p>
                </div>

                <div className="cyber-card rounded-2xl p-5 bg-slate-900/40 border border-slate-800/80 space-y-2">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-slate-100">False-Positive Resistance</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Tuned across academic, creative, professional, and technical modes to prevent penalizing
                    rigorous formal writing, ESL authors, or technical documentation.
                  </p>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* History Modal */}
      <HistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onSelectScan={(item) => {
          if (item.modality === 'image' && item.imageResult) {
            setActiveModality('image');
          } else if (item.modality === 'audio' && item.audioResult) {
            setActiveModality('audio');
          } else if (item.modality === 'docs' && item.docResult) {
            setActiveModality('docs');
          } else if (item.textResult) {
            setActiveModality('text');
            setScanResult(item.textResult);
            setText(item.textResult.text);
            setMode(item.textResult.mode || 'general');
          }
          setIsCompareMode(false);
        }}
        onClearHistory={handleClearHistory}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/80 py-6 mt-12 text-center text-xs text-slate-400 font-mono no-print">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span className="text-slate-300 font-bold">DeepScan AI</span>
            <span>— Advanced Multimodal Forensics (Text • Image • Audio • Docs)</span>
          </div>
          <div>Powered by Gemini 3.8 Multimodal Core & Statistical Forensics</div>
        </div>
      </footer>
    </div>
  );
}
