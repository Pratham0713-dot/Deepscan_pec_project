export interface SampleText {
  id: string;
  title: string;
  category: 'Synthetic AI' | 'Authentic Human' | 'Mixed AI & Human' | 'Academic Human' | 'Synthetic Marketing';
  expectedProb: string;
  description: string;
  text: string;
}

export const SAMPLE_TEXTS: SampleText[] = [
  {
    id: 'sample-ai-essay',
    title: 'Healthcare AI (ChatGPT-4 Synthetic)',
    category: 'Synthetic AI',
    expectedProb: '92% - 98% AI',
    description: 'Archetypal generative essay filled with synthetic transitions, uniform sentence cadences, and telltale tropes.',
    text: `In today's fast-paced digital landscape, artificial intelligence has emerged as a beacon of innovation across the healthcare ecosystem. As modern medicine continues to evolve, machine learning algorithms play a pivotal role in revolutionizing patient diagnosis and treatment methodologies. Furthermore, by analyzing vast repositories of clinical data, these sophisticated systems delve deep into intricate genetic markers that would otherwise elude the human eye.

It is crucial to recognize that the integration of artificial intelligence is not merely a technological upgrade, but a profound testament to human ingenuity. Healthcare practitioners are now equipped with predictive analytics that foster a sense of proactive intervention rather than reactive care. Moreover, the seamless collaboration between physician intuition and algorithmic precision creates a rich tapestry of modern medical triumphs.

In conclusion, navigating the complexities of tomorrow's healthcare requires a balanced synthesis of technological prowess and ethical stewardship. As we stand on the precipice of a new medical era, embracing these transformative tools will undoubtedly illuminate the path toward unparalleled patient care and prolonged human vitality.`,
  },
  {
    id: 'sample-human-essay',
    title: 'Mountain Ascent (Raw Human Reflection)',
    category: 'Authentic Human',
    expectedProb: '2% - 10% AI',
    description: 'High burstiness, erratic sentence rhythms, visceral personal sensory details, and zero AI clichés.',
    text: `My crampons scraped violently against black ice. At 22,000 feet, every breath tasted like crushed glass and aluminum foil. My partner Dave was twenty yards ahead, his neon green Gore-Tex jacket little more than a bobbing speck amidst the blowing drift. He didn't stop. He couldn't. If you stop moving up here past 2 p.m., the wind chews straight through your marrow before you even realize your toes have gone numb.

I checked my watch: 14:18. Two miles of sheer granite left.

Nobody warns you about the psychological static—that dull, throbbing hum in your skull when oxygen saturation drops under seventy percent. You start hallucinating hot coffee. Genuine black diner coffee in chipped ceramic mugs. I swore I could smell bacon frying in a diner booth in rural Wyoming while clinging by three fingers to a wind-blasted ridge in the Karakoram. Crazy what the starved brain does to keep from admitting terror. We summited at sunset. Not with triumphant speeches, just quiet shivering and a fist bump through frozen mittens.`,
  },
  {
    id: 'sample-mixed-article',
    title: 'Cloud Architecture (Mixed Human + AI Polish)',
    category: 'Mixed AI & Human',
    expectedProb: '45% - 65% AI',
    description: 'Human engineering notes partially rewritten or expanded using an AI assistant.',
    text: `We migrated our core event stream pipeline from self-hosted Kafka clusters to a managed event hub last quarter. The initial latency was unacceptable, pushing nearly 450 milliseconds per batch write during peak morning spikes. I spent three straight nights rewriting the partition distribution logic in Go.

Furthermore, leveraging decoupled serverless workers plays an essential role in optimizing downstream processing workloads. In today's distributed software paradigm, maintaining seamless elasticity is crucial for high-throughput enterprise resilience. By orchestrating resilient message queues and automating horizontal pod autoscaling, organizations can delve into dynamic infrastructure efficiencies that guarantee ninety-nine point nine percent uptime.

We ended up cutting our AWS billing by thirty-two percent while dropping p99 latency down to eighty milliseconds flat. The transition had plenty of messy edge cases, but the throughput gains speak for themselves.`,
  },
  {
    id: 'sample-academic-human',
    title: 'Biochemistry Research Abstract (Formal Human)',
    category: 'Academic Human',
    expectedProb: '8% - 20% AI',
    description: 'Dense formal academic prose written by human researchers without synthetic filler patterns.',
    text: `Phosphorylation kinetics of eukaryotic translation initiation factor 2 alpha (eIF2α) were quantified across seven murine hepatocyte cell lines subjected to endoplasmic reticulum stress induced by tunicamycin (2.5 μg/mL). Immunoblot assays revealed a biphasic attenuation in global polypeptide translation within forty minutes post-exposure. Contrary to previous canonical models, PERK-mediated phosphorylation did not exhibit monotonic escalation; rather, transient dephosphorylation occurred at the ninety-minute mark, regulated by GADD34-PP1c phosphatase complex recruitment. These empirical observations dispute single-pathway feedback assumptions and propose an oscillatory transcriptional checkpoint during acute unfolded protein responses.`,
  },
  {
    id: 'sample-synthetic-marketing',
    title: 'SaaS Value Proposition (Synthetic Marketing Pitch)',
    category: 'Synthetic Marketing',
    expectedProb: '90% - 99% AI',
    description: 'Over-optimized, buzzword-heavy AI product copy with standard synthetic optimism.',
    text: `Unlock the true potential of your enterprise workflow with our game-changing collaborative ecosystem. Designed to empower forward-thinking teams, our intuitive platform seamlessly bridges the gap between visionary ideation and actionable execution. In an increasingly interconnected global economy, driving sustainable synergy across cross-functional departments is more pivotal than ever before. 

Experience the power of frictionless collaboration as our state-of-the-art automation suite streamlines mission-critical operations. Discover how leading industry pioneers are harnessing this transformative solution to foster unparalleled growth, elevate customer engagement, and cultivate lasting digital excellence. Join us on this revolutionary journey today.`,
  },
];
