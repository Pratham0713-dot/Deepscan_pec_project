import React from 'react';
import { ShieldCheck, History, GitCompare, Sparkles, FileText, Image as ImageIcon, Mic, BookOpen } from 'lucide-react';
import { ForensicModality } from '../types';

interface HeaderProps {
  activeModality: ForensicModality;
  onChangeModality: (modality: ForensicModality) => void;
  onOpenHistory: () => void;
  onOpenCompare: () => void;
  isCompareMode: boolean;
  historyCount: number;
  onReset: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeModality,
  onChangeModality,
  onOpenHistory,
  onOpenCompare,
  isCompareMode,
  historyCount,
  onReset,
}) => {
  const modalities: { id: ForensicModality; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'text', label: 'Text Forensics', icon: FileText },
    { id: 'image', label: 'Image Forensics', icon: ImageIcon },
    { id: 'audio', label: 'Audio / Voice', icon: Mic },
    { id: 'docs', label: 'Document Audit', icon: BookOpen },
  ];

  return (
    <header className="border-b border-slate-800 bg-slate-950/85 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="h-16 flex items-center justify-between">
          {/* Brand */}
          <div className="flex items-center space-x-3 cursor-pointer select-none" onClick={onReset}>
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-sky-500 to-indigo-600 shadow-lg shadow-cyan-500/20">
              <ShieldCheck className="w-6 h-6 text-white" />
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                  DeepScan
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full font-mono font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                  AI FORENSICS
                </span>
              </div>
              <p className="text-[10px] text-slate-400 tracking-wider uppercase font-mono">
                Multimodal Neural Detection Engine
              </p>
            </div>
          </div>

          {/* Center: Modality Tabs for Desktop */}
          <div className="hidden md:flex items-center space-x-1 p-1 bg-slate-900/90 rounded-xl border border-slate-800">
            {modalities.map((m) => {
              const Icon = m.icon;
              const isActive = activeModality === m.id && !isCompareMode;
              return (
                <button
                  key={m.id}
                  onClick={() => onChangeModality(m.id)}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/10'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{m.label}</span>
                </button>
              );
            })}
          </div>

          {/* Status & Navigation Actions */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Compare Mode Toggle */}
            <button
              onClick={onOpenCompare}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                isCompareMode
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/20'
                  : 'text-slate-300 hover:text-white bg-slate-900/60 hover:bg-slate-800 border border-slate-800'
              }`}
              title="Compare two drafts side-by-side"
            >
              <GitCompare className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Compare Diff</span>
            </button>

            {/* History Drawer Button */}
            <button
              onClick={onOpenHistory}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-slate-900/60 hover:bg-slate-800 border border-slate-800 transition-all cursor-pointer"
              title="View scan history"
            >
              <History className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">History</span>
              {historyCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-slate-800 text-[10px] font-mono text-cyan-400 border border-slate-700">
                  {historyCount}
                </span>
              )}
            </button>

            {/* New Scan Reset */}
            <button
              onClick={onReset}
              className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">New Scan</span>
              <span className="sm:hidden">Reset</span>
            </button>
          </div>
        </div>

        {/* Mobile Modality Tabs Row */}
        <div className="flex md:hidden items-center justify-between space-x-1 py-2 border-t border-slate-800/80 overflow-x-auto">
          {modalities.map((m) => {
            const Icon = m.icon;
            const isActive = activeModality === m.id && !isCompareMode;
            return (
              <button
                key={m.id}
                onClick={() => onChangeModality(m.id)}
                className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3 h-3" />
                <span>{m.label.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
