import React, { useState } from 'react';
import { Sparkles, ArrowRight, Check, Copy, RefreshCw, Zap, ShieldCheck } from 'lucide-react';

interface HumanizerStudioProps {
  originalText: string;
  onScanNewText: (text: string) => void;
}

export const HumanizerStudio: React.FC<HumanizerStudioProps> = ({
  originalText,
  onScanNewText,
}) => {
  const [humanizedText, setHumanizedText] = useState<string>('');
  const [changes, setChanges] = useState<string[]>([]);
  const [estimatedAiScore, setEstimatedAiScore] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  const handleHumanize = async () => {
    if (!originalText.trim()) return;
    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/humanize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: originalText }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'Failed to humanize content.');
      }

      const data = await res.json();
      setHumanizedText(data.humanizedText || '');
      setChanges(data.changesApplied || []);
      setEstimatedAiScore(data.estimatedNewAiScore ?? 12);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An error occurred while humanizing the text.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!humanizedText) return;
    navigator.clipboard.writeText(humanizedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="cyber-card rounded-2xl p-6 bg-slate-900/60 border border-slate-800 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-tr from-emerald-500/20 to-cyan-500/20 text-emerald-400 border border-emerald-500/30">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-base font-bold text-slate-100">
              DeepScan Humanizer & De-Synthesizer
            </h4>
            <p className="text-xs text-slate-400">
              Transform formulaic machine phrasing into natural, rhythmic human discourse
            </p>
          </div>
        </div>

        <button
          onClick={handleHumanize}
          disabled={isLoading || !originalText.trim()}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 disabled:opacity-50 text-white text-xs font-semibold shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
        >
          {isLoading ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Analyzing & Humanizing...</span>
            </>
          ) : (
            <>
              <Zap className="w-3.5 h-3.5" />
              <span>Humanize Full Text</span>
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {error}
        </div>
      )}

      {/* Side-by-Side Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Original Flagged Text */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-slate-400">
              Original Flagged Passage
            </span>
            <span className="text-[11px] font-mono text-slate-500">
              {originalText.split(/\s+/).filter(Boolean).length} words
            </span>
          </div>
          <div className="h-64 overflow-y-auto p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-300 text-xs leading-relaxed font-sans">
            {originalText}
          </div>
        </div>

        {/* Right: Humanized Output */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-emerald-400 flex items-center space-x-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Humanized Organic Version</span>
            </span>
            {estimatedAiScore !== null && (
              <span className="text-[11px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                Est. AI: ~{estimatedAiScore}%
              </span>
            )}
          </div>
          <div className="h-64 overflow-y-auto p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-200 text-xs leading-relaxed font-sans relative">
            {humanizedText ? (
              humanizedText
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 p-4">
                <Sparkles className="w-8 h-8 text-slate-700 mb-2" />
                <p className="text-xs">
                  Click "Humanize Full Text" above to rewrite the passage with natural human burstiness, varied clauses, and purged clichés.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Actions and Structural Changes Log */}
      {humanizedText && (
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopy}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied to Clipboard</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Humanized Text</span>
                  </>
                )}
              </button>

              <button
                onClick={() => onScanNewText(humanizedText)}
                className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                <span>Re-Scan this Humanized Text</span>
              </button>
            </div>
          </div>

          {changes.length > 0 && (
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-2">
                Applied Linguistic Transformations
              </span>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                {changes.map((c, idx) => (
                  <li key={idx} className="flex items-start space-x-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{c}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
