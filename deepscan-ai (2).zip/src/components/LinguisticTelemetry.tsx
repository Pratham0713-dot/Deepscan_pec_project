import React from 'react';
import { MetricScores, WritingStyleAnalysis, AlgorithmicStats } from '../types';
import { Activity, BarChart2, BookOpen, Fingerprint, Waves, HelpCircle } from 'lucide-react';

interface LinguisticTelemetryProps {
  metrics: MetricScores;
  styleAnalysis: WritingStyleAnalysis;
  algorithmicStats?: AlgorithmicStats;
}

export const LinguisticTelemetry: React.FC<LinguisticTelemetryProps> = ({
  metrics: incomingMetrics,
  styleAnalysis: incomingStyle,
  algorithmicStats,
}) => {
  const metrics = incomingMetrics || {
    perplexityScore: 50,
    perplexityLabel: 'Moderate',
    burstinessScore: 50,
    burstinessLabel: 'Moderate Rhythm',
    vocabularyEntropy: 50,
    syntacticMonotony: 45,
    aiWatermarkMarkers: 0,
  };

  const styleAnalysis = incomingStyle || {
    tone: 'Standard / Neutral',
    readingGradeLevel: 'Grade 12',
    averageSentenceLength: 16,
    emotionalVariance: 'Moderate Expressiveness',
  };

  // Extract or calculate sentence lengths for the rhythm graph
  const sentenceLengths = algorithmicStats?.sentenceLengths || [];
  const maxLen = Math.max(30, ...sentenceLengths);

  return (
    <div className="space-y-6">
      {/* Top Grid: Perplexity and Burstiness Deep Dives */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Perplexity Metric Card */}
        <div className="cyber-card rounded-2xl p-6 bg-slate-900/60 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                <Fingerprint className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-100">Perplexity Score</h4>
                <p className="text-xs text-slate-400">Vocabulary Predictability & N-Gram Entropy</p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-2xl font-mono font-extrabold text-cyan-400">
                {metrics.perplexityScore}
                <span className="text-xs text-slate-500 font-normal">/100</span>
              </span>
              <span className="block text-[10px] font-mono text-slate-400">
                {metrics.perplexityLabel}
              </span>
            </div>
          </div>

          {/* Progress Bar */}
          <div>
            <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-rose-500 via-amber-500 to-cyan-400 transition-all duration-700"
                style={{ width: `${metrics.perplexityScore}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
              <span>0 (Predictable / Machine)</span>
              <span>50 (Standard)</span>
              <span>100 (High / Organic)</span>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
            Perplexity measures how surprised a language model is by the sequence of words. Lower
            perplexity indicates standardized greedy-search token pathways typical of generative
            models. High perplexity reflects natural human idioms and idiosyncratic vocabulary choices.
          </p>
        </div>

        {/* Burstiness Metric Card */}
        <div className="cyber-card rounded-2xl p-6 bg-slate-900/60 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                <Waves className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-100">Burstiness Index</h4>
                <p className="text-xs text-slate-400">Sentence Length & Cadence Variance</p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-2xl font-mono font-extrabold text-indigo-400">
                {metrics.burstinessScore}
                <span className="text-xs text-slate-500 font-normal">/100</span>
              </span>
              <span className="block text-[10px] font-mono text-slate-400">
                {metrics.burstinessLabel}
              </span>
            </div>
          </div>

          {/* Progress Bar */}
          <div>
            <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-rose-500 via-amber-500 to-indigo-500 transition-all duration-700"
                style={{ width: `${metrics.burstinessScore}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
              <span>0 (Robotic Cadence)</span>
              <span>50 (Moderate Rhythm)</span>
              <span>100 (Dynamic Human Burst)</span>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
            Burstiness reflects rhythmic irregularity in human writing. While humans naturally oscillate
            between ultra-short phrases and lengthy complex clauses, AI language models tend to settle into
            a uniform cadence around 18–24 words per sentence.
          </p>
        </div>
      </div>

      {/* Burstiness Rhythm Waveform / Sentence Length Histogram */}
      {sentenceLengths.length > 0 && (
        <div className="cyber-card rounded-2xl p-6 bg-slate-900/60 border border-slate-800 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h4 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
                <BarChart2 className="w-4 h-4 text-cyan-400" />
                <span>Sentence Cadence Waveform (Word Count Per Sentence)</span>
              </h4>
              <p className="text-xs text-slate-400">
                Visualizing syntactic rhythm across {sentenceLengths.length} sentences. Spikes show human burstiness.
              </p>
            </div>
            <div className="flex items-center space-x-3 text-xs font-mono text-slate-400">
              <span className="flex items-center space-x-1">
                <span className="w-2.5 h-2.5 rounded bg-cyan-500 inline-block" />
                <span>Actual Sentences</span>
              </span>
              <span className="flex items-center space-x-1 text-slate-400">
                <span className="w-3 border-t-2 border-dashed border-rose-400 inline-block" />
                <span>Avg: {styleAnalysis.averageSentenceLength} words</span>
              </span>
            </div>
          </div>

          {/* Histogram Bars */}
          <div className="h-32 flex items-end space-x-1 sm:space-x-1.5 pt-6 pb-2 px-2 bg-slate-950/70 rounded-xl border border-slate-800/80 overflow-x-auto">
            {sentenceLengths.map((len, idx) => {
              const heightPct = Math.min(100, Math.max(12, (len / maxLen) * 100));
              const isUniformRange = len >= 16 && len <= 24;
              return (
                <div
                  key={idx}
                  className="flex-1 min-w-[14px] flex flex-col items-center group relative cursor-pointer"
                >
                  {/* Tooltip on hover */}
                  <div className="absolute -top-9 hidden group-hover:flex z-30 bg-slate-900 text-[10px] font-mono text-cyan-300 px-2 py-1 rounded border border-cyan-500/40 whitespace-nowrap shadow-lg">
                    S#{idx + 1}: {len} words
                  </div>

                  <div
                    className={`w-full rounded-t transition-all duration-300 ${
                      isUniformRange
                        ? 'bg-amber-500/70 group-hover:bg-amber-400'
                        : 'bg-cyan-500/70 group-hover:bg-cyan-400'
                    }`}
                    style={{ height: `${heightPct}%` }}
                  />
                  <span className="text-[9px] font-mono text-slate-400 mt-1">
                    {idx + 1}
                  </span>
                </div>
              );
            })}
          </div>
          <p className="text-[11px] text-slate-400 font-mono">
            * Amber bars represent the 16-24 word bracket, the typical statistical baseline for synthesized outputs.
          </p>
        </div>
      )}

      {/* Secondary Metrics: Style, Readability & Monotony */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
          <span className="text-xs uppercase font-mono tracking-wider text-slate-400 block mb-1">
            Detected Tone
          </span>
          <span className="text-sm font-semibold text-slate-100 block">{styleAnalysis.tone}</span>
          <span className="text-[11px] text-slate-400 block mt-1">Linguistic voice profile</span>
        </div>

        <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
          <span className="text-xs uppercase font-mono tracking-wider text-slate-400 block mb-1">
            Reading Grade Level
          </span>
          <span className="text-sm font-semibold text-slate-100 block">
            {styleAnalysis.readingGradeLevel}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Flesch-Kincaid index</span>
        </div>

        <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
          <span className="text-xs uppercase font-mono tracking-wider text-slate-400 block mb-1">
            Syntactic Monotony
          </span>
          <div className="flex items-center space-x-2">
            <span className="text-sm font-mono font-bold text-amber-400">
              {metrics.syntacticMonotony}%
            </span>
            <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500"
                style={{ width: `${metrics.syntacticMonotony}%` }}
              />
            </div>
          </div>
          <span className="text-[11px] text-slate-400 block mt-1">Repetitive clause structures</span>
        </div>

        <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
          <span className="text-xs uppercase font-mono tracking-wider text-slate-400 block mb-1">
            Emotional Variance
          </span>
          <span className="text-sm font-semibold text-slate-100 block">
            {styleAnalysis.emotionalVariance}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Affective nuance & conviction</span>
        </div>
      </div>
    </div>
  );
};
