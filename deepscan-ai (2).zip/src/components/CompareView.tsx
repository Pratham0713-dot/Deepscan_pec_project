import React, { useState } from 'react';
import { GitCompare, ArrowRight, RefreshCw, CheckCircle, AlertTriangle, Cpu, User } from 'lucide-react';
import { AnalysisResult } from '../types';

interface CompareViewProps {
  onClose: () => void;
}

export const CompareView: React.FC<CompareViewProps> = ({ onClose }) => {
  const [textA, setTextA] = useState<string>('');
  const [textB, setTextB] = useState<string>('');
  const [resultA, setResultA] = useState<AnalysisResult | null>(null);
  const [resultB, setResultB] = useState<AnalysisResult | null>(null);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleRunComparison = async () => {
    if (!textA.trim() || !textB.trim()) {
      setError('Please provide text for both Document A and Document B to compare.');
      return;
    }

    setIsScanning(true);
    setError(null);

    try {
      const [resA, resB] = await Promise.all([
        fetch('/api/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: textA }),
        }),
        fetch('/api/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: textB }),
        }),
      ]);

      if (!resA.ok || !resB.ok) {
        throw new Error('Failed to analyze one or both documents.');
      }

      const dataA = await resA.json();
      const dataB = await resB.json();

      setResultA({ ...dataA, id: 'compare-a', timestamp: new Date().toISOString(), text: textA, mode: 'general' });
      setResultB({ ...dataB, id: 'compare-b', timestamp: new Date().toISOString(), text: textB, mode: 'general' });
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error occurred while comparing documents.');
    } finally {
      setIsScanning(false);
    }
  };

  const deltaAi = resultA && resultB ? resultA.overallAiProbability - resultB.overallAiProbability : null;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <GitCompare className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100">Dual Document Comparison</h3>
            <p className="text-xs text-slate-400">
              Compare original vs revised drafts to measure AI probability reduction
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors"
          >
            Back to Single Scan
          </button>
          <button
            onClick={handleRunComparison}
            disabled={isScanning || !textA.trim() || !textB.trim()}
            className="flex items-center space-x-1.5 px-4 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
          >
            {isScanning ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Comparing Both...</span>
              </>
            ) : (
              <>
                <GitCompare className="w-3.5 h-3.5" />
                <span>Compare Versions</span>
              </>
            )}
          </button>
        </div>
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {error}
        </div>
      )}

      {/* Delta Banner when results are ready */}
      {deltaAi !== null && resultA && resultB && (
        <div className="p-4 rounded-xl bg-slate-900/80 border border-cyan-500/30 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div
              className={`p-2.5 rounded-xl font-mono text-base font-bold ${
                deltaAi > 0
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                  : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
              }`}
            >
              {deltaAi > 0 ? `-${deltaAi}% AI` : `+${Math.abs(deltaAi)}% AI`}
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-100">
                {deltaAi > 0
                  ? 'Significant Humanization Detected'
                  : deltaAi === 0
                  ? 'Identical AI Footprint'
                  : 'Document B Has Higher AI Patterns'}
              </h4>
              <p className="text-xs text-slate-400">
                Document A ({resultA.overallAiProbability}% AI) → Document B ({resultB.overallAiProbability}% AI)
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Input / Result Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Document A */}
        <div className="cyber-card rounded-2xl p-5 bg-slate-900/50 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-slate-400">
              Document A (e.g. Original Draft)
            </span>
            {resultA && (
              <span className="text-xs font-mono font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                AI: {resultA.overallAiProbability}%
              </span>
            )}
          </div>

          <textarea
            value={textA}
            onChange={(e) => setTextA(e.target.value)}
            placeholder="Paste first version of text..."
            className="w-full h-56 p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-200 text-xs font-sans leading-relaxed resize-none focus:outline-none focus:border-cyan-500/50"
          />

          {resultA && (
            <div className="pt-2 border-t border-slate-800/80 space-y-2 text-xs">
              <div className="flex justify-between text-slate-400 font-mono">
                <span>Burstiness: {resultA.metrics.burstinessScore}/100</span>
                <span>Perplexity: {resultA.metrics.perplexityScore}/100</span>
                <span>Tropes: {resultA.detectedAiTropes.length}</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed italic bg-slate-950/50 p-2 rounded">
                "{resultA.verdict}"
              </p>
            </div>
          )}
        </div>

        {/* Document B */}
        <div className="cyber-card rounded-2xl p-5 bg-slate-900/50 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-emerald-400">
              Document B (e.g. Revised / Edited Draft)
            </span>
            {resultB && (
              <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                AI: {resultB.overallAiProbability}%
              </span>
            )}
          </div>

          <textarea
            value={textB}
            onChange={(e) => setTextB(e.target.value)}
            placeholder="Paste second version of text..."
            className="w-full h-56 p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-200 text-xs font-sans leading-relaxed resize-none focus:outline-none focus:border-cyan-500/50"
          />

          {resultB && (
            <div className="pt-2 border-t border-slate-800/80 space-y-2 text-xs">
              <div className="flex justify-between text-slate-400 font-mono">
                <span>Burstiness: {resultB.metrics.burstinessScore}/100</span>
                <span>Perplexity: {resultB.metrics.perplexityScore}/100</span>
                <span>Tropes: {resultB.detectedAiTropes.length}</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed italic bg-slate-950/50 p-2 rounded">
                "{resultB.verdict}"
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
