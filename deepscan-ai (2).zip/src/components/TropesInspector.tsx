import React from 'react';
import { DetectedTrope } from '../types';
import { AlertTriangle, CheckCircle2, Lightbulb, Search, BookMarked } from 'lucide-react';

interface TropesInspectorProps {
  tropes: DetectedTrope[];
  recommendations: string[];
}

export const TropesInspector: React.FC<TropesInspectorProps> = ({
  tropes,
  recommendations,
}) => {
  return (
    <div className="space-y-6">
      {/* Header explanation banner */}
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-start space-x-3">
        <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20 shrink-0">
          <BookMarked className="w-5 h-5" />
        </div>
        <div>
          <h4 className="text-sm font-bold text-slate-100">
            Synthetic N-Gram Fingerprints & Tropes
          </h4>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Large Language Models are trained on probability minimization, which causes them to gravitate
            toward specific high-frequency transition phrases, dramatic metaphors, and generic connectors
            rarely used in organic human discourse.
          </p>
        </div>
      </div>

      {/* Tropes Grid */}
      {tropes.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {tropes.map((trope, idx) => (
            <div
              key={idx}
              className="cyber-card rounded-xl p-4 bg-slate-900/50 border border-slate-800 hover:border-slate-700 transition-all space-y-2.5"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-mono font-bold text-rose-400 bg-rose-500/10 px-2.5 py-1 rounded-md border border-rose-500/20">
                  "{trope.phrase}"
                </span>
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                    {trope.category}
                  </span>
                  <span className="text-xs font-mono font-semibold text-rose-300 bg-rose-950/60 px-2 py-0.5 rounded border border-rose-800/40">
                    {trope.occurrences}x
                  </span>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {trope.explanation}
              </p>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-10 rounded-2xl bg-slate-900/30 border border-slate-800/80">
          <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2 opacity-80" />
          <h4 className="text-sm font-semibold text-slate-200">Zero Synthetic Tropes Detected</h4>
          <p className="text-xs text-slate-400 max-w-md mx-auto mt-1">
            This document does not contain recognizable stereotypical AI clichés like "delve into", "rich tapestry", or "beacon of innovation".
          </p>
        </div>
      )}

      {/* Actionable Recommendations Section */}
      {recommendations && recommendations.length > 0 && (
        <div className="cyber-card rounded-2xl p-6 bg-slate-900/60 border border-slate-800 space-y-4">
          <div className="flex items-center space-x-2">
            <Lightbulb className="w-5 h-5 text-amber-400" />
            <h4 className="text-base font-bold text-slate-100">
              Forensic Authenticity Recommendations
            </h4>
          </div>

          <div className="space-y-2.5">
            {recommendations.map((rec, rIdx) => (
              <div
                key={rIdx}
                className="flex items-start space-x-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80"
              >
                <span className="w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400 flex items-center justify-center text-xs font-mono font-bold shrink-0 mt-0.5 border border-cyan-500/20">
                  {rIdx + 1}
                </span>
                <p className="text-xs text-slate-300 leading-relaxed font-sans">{rec}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
