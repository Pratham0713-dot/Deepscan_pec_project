import React, { useState, useRef } from 'react';
import { DocumentAnalysisResult } from '../types';
import { SentenceHeatmap } from './SentenceHeatmap';
import {
  FileText,
  Upload,
  Search,
  BookOpen,
  Award,
  Layers,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  FileCheck,
  ShieldAlert,
  Clock,
  Binary,
  Sparkles,
} from 'lucide-react';

const SAMPLE_DOCS = [
  {
    id: 'sample-doc-thesis',
    title: 'AI_Generated_Dissertation_Draft.pdf',
    category: 'AI Thesis Draft',
    expected: '91% AI',
    fileSizeKb: 84,
    pageCount: 5,
    description: 'Multi-chapter academic draft generated via LLM with formulaic citations and low burstiness.',
    text: `Executive Summary & Abstract
In today's fast-paced digital landscape, machine learning architectures play a pivotal role in optimizing distributed computing infrastructures. By leveraging deep neural networks, organizations can delve into intricate algorithmic patterns that unlock unprecedented computational efficiencies. Furthermore, these technological paradigms foster a sense of continuous innovation across enterprise pipelines.

Literature Review & Contextual Framework
A thorough examination of current scholarship reveals a rich tapestry of distributed consensus protocols. As demonstrated in previous treatises, algorithmic synchronization stands as a testament to modern software engineering. It is crucial to recognize that decentralized ledger technologies continue to serve as a beacon of cryptographic resilience. Moreover, navigating the complexities of consensus requires a balanced synthesis of fault tolerance and high throughput.

Methodology & Quantitative Findings
Experimental evaluations were conducted across thirty cluster nodes utilizing simulated network latency of forty-five milliseconds. The empirical data indicates a monotonic decrease in throughput when packet loss exceeded three percent. While the initial cluster configuration demonstrated acceptable fault recovery, subsequent stress tests revealed standard performance ceilings typical of Byzantine architectures.

Concluding Remarks
In conclusion, the integration of autonomous consensus mechanisms represents an essential milestone for future distributed platforms. As computational demands continue to escalate, adhering to rigorous architectural principles will illuminate the pathway toward dependable systems.`,
  },
  {
    id: 'sample-doc-human',
    title: 'Peer_Reviewed_Biochemistry_Study.pdf',
    category: 'Human Study',
    expected: '8% AI (Authentic)',
    fileSizeKb: 142,
    pageCount: 8,
    description: 'Authentic empirical paper written by university researchers with verified experimental logs and high burstiness.',
    text: `Abstract
We report the synthesis and stereochemical characterization of twelve novel macrocyclic inhibitors targeting histone deacetylase 6 (HDAC6). Compound 4b demonstrated potent nanomolar inhibition (IC50 = 4.2 ± 0.6 nM) with >120-fold selectivity over HDAC1. X-ray crystallographic coordinates revealed unexpected coordination with the catalytic zinc ion via a bidentate hydroxamate motif.

Experimental Procedures & Synthesis
Reagents were purchased from Sigma-Aldrich and utilized without additional recrystallization. Flash chromatography was performed on silica gel (230-400 mesh, 60 Å). Proton NMR spectra (400 MHz, CDCl3) yielded distinct chemical shifts at δ 7.82 (d, J = 8.4 Hz, 2H) and δ 3.45 (m, 4H). We observed transient degradation when exposed to temperatures exceeding 45 °C during solvent rotary evaporation, necessitating chilled nitrogen purge protocols.

In Vitro Pharmacokinetic Profiling
Microsomal clearance assays in human liver S9 fractions revealed a half-life of 74 minutes. Cellular viability was assessed across MCF-7 and A549 cell lines via standard MTT colorimetric readouts at twenty-four, forty-eight, and seventy-two hour intervals. Notably, cytotoxic synergy occurred when paired with paclitaxel at 10 nM concentrations.`,
  },
];

interface DocumentForensicsViewProps {
  onSaveToHistory: (result: DocumentAnalysisResult) => void;
}

export const DocumentForensicsView: React.FC<DocumentForensicsViewProps> = ({ onSaveToHistory }) => {
  const [docTitle, setDocTitle] = useState<string>(SAMPLE_DOCS[0].title);
  const [docText, setDocText] = useState<string>(SAMPLE_DOCS[0].text);
  const [fileSizeKb, setFileSizeKb] = useState<number>(SAMPLE_DOCS[0].fileSizeKb);
  const [pageCount, setPageCount] = useState<number>(SAMPLE_DOCS[0].pageCount);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [result, setResult] = useState<DocumentAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showFullSentenceMap, setShowFullSentenceMap] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setDocTitle(file.name);
    const size = Math.round(file.size / 1024);
    setFileSizeKb(size);

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setDocText(content || '');
      setPageCount(Math.max(1, Math.ceil((content || '').split(/\s+/).length / 320)));
      setResult(null);
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleRunScan = async (overrideText?: string, overrideTitle?: string) => {
    const textToScan = overrideText || docText;
    const titleToScan = overrideTitle || docTitle;
    if (!textToScan.trim()) return;

    setIsScanning(true);
    setError(null);

    try {
      const res = await fetch('/api/analyze-doc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: textToScan,
          documentName: titleToScan,
          fileSizeKb,
          pageCount,
        }),
      });

      if (!res.ok) {
        throw new Error('Document forensic analysis failed.');
      }

      const data: DocumentAnalysisResult = await res.json();
      setResult(data);
      onSaveToHistory(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error executing document forensics.');
    } finally {
      setIsScanning(false);
    }
  };

  const isHighAi = (result?.overallAiProbability ?? 0) >= 70;
  const isModerateAi = (result?.overallAiProbability ?? 0) >= 35 && (result?.overallAiProbability ?? 0) < 70;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-2 max-w-3xl mx-auto">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Multi-Page Document & Citation Forensics</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
          Audit PDF, Word & Academic Documents
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          Scan multi-page dissertations, research papers, and corporate docs for chapter-by-chapter AI
          distribution, fabricated bibliography citations, and suspicious revision metadata.
        </p>
      </div>

      {/* Preset Documents */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <span className="text-xs font-semibold text-slate-400 flex items-center space-x-1">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Curated Document Benchmarks:</span>
        </span>
        <div className="flex flex-wrap items-center gap-2">
          {SAMPLE_DOCS.map((sample) => (
            <button
              key={sample.id}
              onClick={() => {
                setDocTitle(sample.title);
                setDocText(sample.text);
                setFileSizeKb(sample.fileSizeKb);
                setPageCount(sample.pageCount);
                setResult(null);
                handleRunScan(sample.text, sample.title);
              }}
              className="flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all cursor-pointer"
            >
              <span>{sample.title}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-900 text-cyan-400 border border-slate-800">
                {sample.expected}
              </span>
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {error}
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Document File & Content Preview */}
        <div className="lg:col-span-6 space-y-4">
          <div className="cyber-card rounded-2xl p-5 bg-slate-950/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <FileText className="w-4 h-4 text-cyan-400" />
                <span className="font-semibold text-slate-200">{docTitle}</span>
              </div>
              <div className="flex items-center space-x-2 font-mono text-[11px]">
                <span>{fileSizeKb} KB</span>
                <span>•</span>
                <span>~{pageCount} Pages</span>
              </div>
            </div>

            {/* Document Text Box */}
            <textarea
              value={docText}
              onChange={(e) => {
                setDocText(e.target.value);
                setResult(null);
              }}
              placeholder="Paste or upload document text..."
              className="w-full h-64 p-3 bg-slate-900/50 rounded-xl border border-slate-800 text-slate-200 text-xs font-sans leading-relaxed resize-none focus:outline-none focus:border-cyan-500/50"
            />

            {/* File upload toolbar */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center space-x-1.5 text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload File (.pdf, .docx, .txt, .md)</span>
              </button>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                accept=".pdf,.docx,.txt,.md,.rtf,.csv"
                className="hidden"
              />

              <span className="text-[11px] font-mono text-slate-500">
                {docText.split(/\s+/).filter(Boolean).length} words
              </span>
            </div>
          </div>

          {/* Primary Action Button */}
          <button
            onClick={() => handleRunScan()}
            disabled={isScanning || !docText.trim()}
            className="w-full py-3 rounded-xl font-semibold text-sm bg-gradient-to-r from-cyan-500 via-sky-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 disabled:opacity-50 text-white shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            {isScanning ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Executing Multi-Section Document Audit...</span>
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                <span>Deep Scan Document</span>
              </>
            )}
          </button>
        </div>

        {/* Right Column: Multi-Section Decomposition Dashboard */}
        <div className="lg:col-span-6 space-y-5">
          {result ? (
            <div className="space-y-5 animate-in fade-in duration-300">
              {/* Verdict Header */}
              <div className="cyber-card rounded-2xl p-5 bg-slate-900/70 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center space-x-3">
                  <div
                    className={`p-3 rounded-xl font-mono text-xl font-extrabold ${
                      isHighAi
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                        : isModerateAi
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {result.overallAiProbability}%
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-bold text-white">{result.verdict}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                        {result.confidenceLevel} Confidence
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {result.pageCount} Pages • {result.totalWords} Words • {result.fileSizeKb} KB
                    </p>
                  </div>
                </div>
              </div>

              {/* Chapter-by-Chapter AI Distribution */}
              <div className="cyber-card rounded-2xl p-5 bg-slate-900/60 border border-slate-800 space-y-3">
                <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                  <Layers className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Chapter & Section AI Distribution</span>
                </h4>

                <div className="space-y-2.5">
                  {result.sections.map((section, sIdx) => {
                    const isSecHigh = section.aiProbability >= 70;
                    return (
                      <div
                        key={sIdx}
                        className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs"
                      >
                        <div className="space-y-0.5">
                          <span className="font-semibold text-slate-200 block">
                            {section.title}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">
                            Page {section.pageNumber} • {section.wordCount} words
                          </span>
                        </div>

                        <div className="flex items-center space-x-2">
                          <span
                            className={`font-mono text-xs font-bold px-2 py-0.5 rounded-md ${
                              isSecHigh
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            }`}
                          >
                            {section.aiProbability}% AI
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Citation & Metadata Forensics */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Citation Hallucination Audit */}
                <div className="cyber-card rounded-xl p-4 bg-slate-900/60 border border-slate-800 space-y-2">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center space-x-1">
                    <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Citation Verification</span>
                  </span>
                  <div className="text-sm font-bold text-slate-100">
                    {result.citationAudit.totalCitationsFound} Citations Audited
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {result.citationAudit.notes}
                  </p>
                </div>

                {/* Metadata Revision Integrity */}
                <div className="cyber-card rounded-xl p-4 bg-slate-900/60 border border-slate-800 space-y-2">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center space-x-1">
                    <Clock className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Document Metadata</span>
                  </span>
                  <div className="text-sm font-bold text-slate-100">
                    {result.metadataForensics.creatorApplication}
                  </div>
                  <p className="text-xs text-slate-400 font-mono">
                    Revisions: {result.metadataForensics.revisionCount} • Active Editing: {result.metadataForensics.editingTimeMinutes}m
                  </p>
                </div>
              </div>

              {/* Button to toggle granular sentence heatmap */}
              <button
                onClick={() => setShowFullSentenceMap(!showFullSentenceMap)}
                className="w-full py-2.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 transition-colors cursor-pointer"
              >
                {showFullSentenceMap ? 'Hide Sentence Heatmap' : 'Inspect Sentence-by-Sentence Breakdown'}
              </button>

              {showFullSentenceMap && result.textResult && (
                <div className="pt-2 animate-in fade-in duration-300">
                  <SentenceHeatmap sentences={result.textResult.sentences} />
                </div>
              )}
            </div>
          ) : (
            <div className="cyber-card rounded-2xl p-8 bg-slate-900/30 border border-slate-800 text-center space-y-3">
              <BookOpen className="w-10 h-10 text-slate-600 mx-auto" />
              <h4 className="text-sm font-semibold text-slate-200">Awaiting Document Audit</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Select a sample document or upload your PDF/DOCX file to analyze chapter section
                breakdowns, citation authenticity, and editing history.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
