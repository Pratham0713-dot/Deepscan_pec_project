import React from 'react';
import { ShieldAlert, ShieldCheck, AlertTriangle, Cpu, User, Layers } from 'lucide-react';
import { AnalysisResult } from '../types';

interface ScoreGaugeProps {
  result: AnalysisResult;
}

export const ScoreGauge: React.FC<ScoreGaugeProps> = ({ result }) => {
  const overallAiProbability = Math.min(100, Math.max(0, result.overallAiProbability ?? 50));
  const overallHumanProbability = Math.min(100, Math.max(0, result.overallHumanProbability ?? (100 - overallAiProbability)));
  const confidenceLevel = result.confidenceLevel || 'High';
  const verdict = result.verdict || (overallAiProbability >= 70 ? 'Likely AI-Generated' : overallAiProbability >= 35 ? 'Mixed AI & Human' : 'Likely Human-Written');
  const summary = result.summary || 'Forensic analysis completed.';
  const metrics = result.metrics || {
    perplexityScore: 50,
    perplexityLabel: 'Moderate',
    burstinessScore: 50,
    burstinessLabel: 'Moderate',
    aiWatermarkMarkers: 0,
    vocabularyEntropy: 50,
    syntacticMonotony: 50,
  };

  // Determine color theme based on AI score
  const isHighAi = overallAiProbability >= 70;
  const isModerateAi = overallAiProbability >= 35 && overallAiProbability < 70;
  const isHuman = overallAiProbability < 35;

  const scoreColor = isHighAi
    ? 'text-rose-500'
    : isModerateAi
    ? 'text-amber-500'
    : 'text-emerald-400';

  const strokeColor = isHighAi
    ? '#f43f5e'
    : isModerateAi
    ? '#f59e0b'
    : '#10b981';

  const badgeBg = isHighAi
    ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
    : isModerateAi
    ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
    : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';

  // SVG Gauge calculations (circumference for radius 80)
  const radius = 74;
  const circumference = 2 * Math.PI * radius;
  // We'll show a 240-degree arc
  const arcLength = circumference * (240 / 360);
  const strokeDashoffset = arcLength - (arcLength * overallAiProbability) / 100;

  return (
    <div className="cyber-card rounded-2xl p-6 relative overflow-hidden border border-slate-800 bg-slate-900/60 shadow-xl">
      {/* Background ambient glow */}
      <div
        className={`absolute -top-24 -left-24 w-72 h-72 rounded-full blur-3xl opacity-20 pointer-events-none ${
          isHighAi ? 'bg-rose-600' : isModerateAi ? 'bg-amber-600' : 'bg-emerald-600'
        }`}
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
        {/* Left: Gauge Dial */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center text-center">
          <div className="relative w-52 h-52 flex items-center justify-center">
            {/* SVG Arc Gauge */}
            <svg className="w-full h-full -rotate-120 transform" viewBox="0 0 180 180">
              {/* Background Track */}
              <circle
                cx="90"
                cy="90"
                r={radius}
                className="stroke-slate-800"
                strokeWidth="14"
                fill="none"
                strokeDasharray={`${arcLength} ${circumference}`}
                strokeLinecap="round"
              />
              {/* Value Arc */}
              <circle
                cx="90"
                cy="90"
                r={radius}
                stroke={strokeColor}
                strokeWidth="14"
                fill="none"
                strokeDasharray={`${arcLength} ${circumference}`}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                className="transition-all duration-1000 ease-out"
                style={{
                  filter: `drop-shadow(0 0 8px ${strokeColor}44)`,
                }}
              />
            </svg>

            {/* Inner Content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pt-2">
              <span className="text-4xl sm:text-5xl font-extrabold tracking-tight font-mono text-white">
                {overallAiProbability}%
              </span>
              <span className="text-xs uppercase tracking-wider font-semibold text-slate-400 mt-1">
                AI Likelihood
              </span>
              <span
                className={`mt-1.5 text-[11px] font-mono px-2 py-0.5 rounded-full border ${badgeBg}`}
              >
                {confidenceLevel} Confidence
              </span>
            </div>
          </div>

          {/* Quick Probability Distribution Bar */}
          <div className="w-full max-w-xs mt-4">
            <div className="flex justify-between text-xs font-mono text-slate-400 mb-1.5">
              <span className="flex items-center space-x-1 text-rose-400">
                <Cpu className="w-3 h-3" />
                <span>AI: {overallAiProbability}%</span>
              </span>
              <span className="flex items-center space-x-1 text-emerald-400">
                <User className="w-3 h-3" />
                <span>Human: {overallHumanProbability}%</span>
              </span>
            </div>
            <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden flex">
              <div
                className="h-full bg-gradient-to-r from-rose-500 to-amber-500 transition-all duration-700"
                style={{ width: `${overallAiProbability}%` }}
              />
              <div
                className="h-full bg-emerald-500 transition-all duration-700"
                style={{ width: `${overallHumanProbability}%` }}
              />
            </div>
          </div>
        </div>

        {/* Right: Forensic Verdict & Summary */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <div
              className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border ${badgeBg}`}
            >
              {isHighAi ? (
                <ShieldAlert className="w-4 h-4 text-rose-400" />
              ) : isModerateAi ? (
                <AlertTriangle className="w-4 h-4 text-amber-400" />
              ) : (
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              )}
              <span>{verdict}</span>
            </div>
            <span className="text-xs font-mono text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded-full border border-slate-700">
              Scanned: {new Date(result.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>

          <div>
            <h3 className="text-xl font-bold text-slate-100 tracking-tight">
              Linguistic Forensics Assessment
            </h3>
            <p className="mt-2 text-sm text-slate-300 leading-relaxed font-sans">
              {summary}
            </p>
          </div>

          {/* Quick Metrics Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
            <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block">
                Perplexity
              </span>
              <span className="text-base font-bold font-mono text-slate-100">
                {metrics.perplexityScore}/100
              </span>
              <span className="text-[10px] text-slate-400 block truncate" title={metrics.perplexityLabel}>
                {metrics.perplexityLabel}
              </span>
            </div>

            <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block">
                Burstiness
              </span>
              <span className="text-base font-bold font-mono text-slate-100">
                {metrics.burstinessScore}/100
              </span>
              <span className="text-[10px] text-slate-400 block truncate" title={metrics.burstinessLabel}>
                {metrics.burstinessLabel}
              </span>
            </div>

            <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block">
                Tropes Flagged
              </span>
              <span className="text-base font-bold font-mono text-rose-400">
                {metrics.aiWatermarkMarkers} markers
              </span>
              <span className="text-[10px] text-slate-400 block truncate">
                Repetitive clichés
              </span>
            </div>

            <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block">
                Lexical Entropy
              </span>
              <span className="text-base font-bold font-mono text-cyan-400">
                {metrics.vocabularyEntropy}%
              </span>
              <span className="text-[10px] text-slate-400 block truncate">
                Vocabulary diversity
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
