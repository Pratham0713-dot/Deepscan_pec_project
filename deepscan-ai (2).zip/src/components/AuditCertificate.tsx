import React from 'react';
import { AnalysisResult } from '../types';
import { Printer, ShieldCheck, CheckCircle2, Award, Hash, Clock, FileCheck } from 'lucide-react';

interface AuditCertificateProps {
  result: AnalysisResult;
}

// Simple deterministic hash generator for text verification
function generateHash(text: string): string {
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).toUpperCase().padStart(8, '0');
  return `SHA256-${hex}-DS38`;
}

export const AuditCertificate: React.FC<AuditCertificateProps> = ({ result }) => {
  const hash = generateHash(result.text);
  const certId = `DSC-${result.id.slice(0, 8).toUpperCase()}`;

  const isHighAi = result.overallAiProbability >= 70;
  const isModerateAi = result.overallAiProbability >= 35 && result.overallAiProbability < 70;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between no-print">
        <div className="flex items-center space-x-2 text-slate-300 text-sm">
          <FileCheck className="w-5 h-5 text-cyan-400" />
          <span>Official Forensic Certificate of AI Content Authenticity</span>
        </div>
        <button
          onClick={handlePrint}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all cursor-pointer shadow-md"
        >
          <Printer className="w-4 h-4 text-cyan-400" />
          <span>Print / Save as PDF Certificate</span>
        </button>
      </div>

      {/* Printable Certificate Card */}
      <div className="certificate-page cyber-card rounded-2xl p-8 bg-slate-950 border-2 border-slate-700/80 shadow-2xl relative overflow-hidden">
        {/* Subtle Watermark Background */}
        <div className="absolute right-6 -bottom-10 opacity-5 pointer-events-none select-none">
          <Award className="w-80 h-80 text-white" />
        </div>

        {/* Certificate Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b-2 border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-xl bg-cyan-600/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold tracking-tight text-white uppercase font-mono">
                DeepScan AI Forensic Certificate
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                Cryptographic Text Authenticity & Linguistic Decomposition Report
              </p>
            </div>
          </div>

          <div className="text-right font-mono">
            <span className="text-[10px] uppercase text-slate-400 block">Certificate ID</span>
            <span className="text-sm font-bold text-cyan-400">{certId}</span>
          </div>
        </div>

        {/* Content Metadata */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-6 border-b border-slate-800/80 text-xs">
          <div>
            <span className="text-slate-400 font-mono block text-[10px] uppercase">
              Inspection Timestamp
            </span>
            <span className="font-semibold text-slate-200">
              {new Date(result.timestamp).toUTCString()}
            </span>
          </div>
          <div>
            <span className="text-slate-400 font-mono block text-[10px] uppercase">
              Cryptographic Checksum
            </span>
            <span className="font-mono text-slate-300 font-semibold">{hash}</span>
          </div>
          <div>
            <span className="text-slate-400 font-mono block text-[10px] uppercase">
              Engine & Model
            </span>
            <span className="font-mono text-cyan-300">DeepScan Neural Core (gemini-3.8-flash)</span>
          </div>
        </div>

        {/* Verdict Seal & Primary Score */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center py-6 border-b border-slate-800/80">
          <div className="md:col-span-4 flex flex-col items-center justify-center p-6 rounded-2xl bg-slate-900/60 border border-slate-800 text-center">
            <span className="text-xs uppercase font-mono tracking-wider text-slate-400 mb-1">
              AI Likelihood Assessment
            </span>
            <span
              className={`text-5xl font-mono font-extrabold ${
                isHighAi ? 'text-rose-400' : isModerateAi ? 'text-amber-400' : 'text-emerald-400'
              }`}
            >
              {result.overallAiProbability}%
            </span>
            <span className="mt-2 text-xs font-mono font-semibold px-3 py-1 rounded-full bg-slate-800 text-slate-200 border border-slate-700">
              {result.verdict}
            </span>
          </div>

          <div className="md:col-span-8 space-y-3">
            <h4 className="text-sm font-bold text-slate-100 uppercase font-mono tracking-wider">
              Executive Finding Summary
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">{result.summary}</p>

            <div className="grid grid-cols-3 gap-3 pt-2">
              <div className="bg-slate-900/40 p-2.5 rounded-lg border border-slate-800 text-center">
                <span className="text-[10px] font-mono text-slate-400 block">Burstiness Score</span>
                <span className="text-sm font-mono font-bold text-slate-200">
                  {result.metrics.burstinessScore}/100
                </span>
              </div>
              <div className="bg-slate-900/40 p-2.5 rounded-lg border border-slate-800 text-center">
                <span className="text-[10px] font-mono text-slate-400 block">Perplexity Score</span>
                <span className="text-sm font-mono font-bold text-slate-200">
                  {result.metrics.perplexityScore}/100
                </span>
              </div>
              <div className="bg-slate-900/40 p-2.5 rounded-lg border border-slate-800 text-center">
                <span className="text-[10px] font-mono text-slate-400 block">Flagged Tropes</span>
                <span className="text-sm font-mono font-bold text-rose-400">
                  {result.detectedAiTropes.length} phrases
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Text Excerpt Snippet */}
        <div className="pt-6 space-y-2">
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
            Audited Text Excerpt (First 300 characters)
          </span>
          <p className="text-xs text-slate-400 bg-slate-900/40 p-3 rounded-xl border border-slate-800/80 font-mono italic">
            "{result.text.slice(0, 320)}..."
          </p>
        </div>

        {/* Sign-off Seal Footer */}
        <div className="pt-8 mt-6 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs text-slate-500 font-mono">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-cyan-400" />
            <span>Verified by DeepScan AI Algorithmic & Neural Engine</span>
          </div>
          <div>Authorized Forensic Record #{certId}</div>
        </div>
      </div>
    </div>
  );
};
