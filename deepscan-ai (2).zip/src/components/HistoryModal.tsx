import React from 'react';
import { ScanHistoryItem } from '../types';
import { History, Trash2, X, ArrowUpRight, Cpu, FileText, Image as ImageIcon, Mic, BookOpen } from 'lucide-react';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: ScanHistoryItem[];
  onSelectScan: (item: ScanHistoryItem) => void;
  onClearHistory: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  history,
  onSelectScan,
  onClearHistory,
}) => {
  if (!isOpen) return null;

  const getModalityIcon = (mod?: string) => {
    switch (mod) {
      case 'image':
        return <ImageIcon className="w-3.5 h-3.5 text-sky-400" />;
      case 'audio':
        return <Mic className="w-3.5 h-3.5 text-purple-400" />;
      case 'docs':
        return <BookOpen className="w-3.5 h-3.5 text-amber-400" />;
      default:
        return <FileText className="w-3.5 h-3.5 text-cyan-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="cyber-card rounded-2xl w-full max-w-2xl max-h-[85vh] flex flex-col bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">Multimodal Audit History</h3>
              <p className="text-xs text-slate-400">
                {history.length} forensic inspection{history.length !== 1 ? 's' : ''} stored locally
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {history.length > 0 && (
              <button
                onClick={onClearHistory}
                className="flex items-center space-x-1 text-xs text-slate-400 hover:text-rose-400 px-2.5 py-1 rounded bg-slate-800/80 hover:bg-slate-800 transition-colors cursor-pointer"
                title="Clear all stored scans"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* List of scans */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3">
          {history.length > 0 ? (
            history.map((item) => {
              const isHigh = item.overallAiProbability >= 70;
              const isMod = item.overallAiProbability >= 35 && item.overallAiProbability < 70;

              return (
                <div
                  key={item.id}
                  onClick={() => {
                    onSelectScan(item);
                    onClose();
                  }}
                  className="p-3.5 rounded-xl bg-slate-950/60 hover:bg-slate-800/60 border border-slate-800 hover:border-cyan-500/40 transition-all cursor-pointer group flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1 min-w-0 flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-900 border border-slate-800">
                        {getModalityIcon(item.modality)}
                        <span className="text-slate-300 font-semibold">{item.modality || 'text'}</span>
                      </span>

                      <span className="text-xs font-mono text-slate-400">
                        {new Date(item.timestamp).toLocaleDateString()} at{' '}
                        {new Date(item.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <p className="text-xs text-slate-200 line-clamp-1 font-sans">
                      "{item.titleSnippet}"
                    </p>
                  </div>

                  <div className="flex items-center space-x-3 shrink-0">
                    <span
                      className={`text-xs font-mono font-bold px-2.5 py-1 rounded-full border ${
                        isHigh
                          ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                          : isMod
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                          : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                      }`}
                    >
                      {item.overallAiProbability}% AI
                    </span>

                    <span className="text-xs text-slate-500 group-hover:text-cyan-400 transition-colors flex items-center space-x-0.5">
                      <span>Inspect</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-12 text-slate-500 space-y-2">
              <Cpu className="w-10 h-10 mx-auto text-slate-700" />
              <p className="text-sm">No scans in your history yet.</p>
              <p className="text-xs text-slate-600">
                Run a text, image, audio, or document scan to store forensic reports.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
