import React, { useRef, useState } from 'react';
import { ScanMode } from '../types';
import { SAMPLE_TEXTS, SampleText } from '../data/samples';
import {
  Search,
  Upload,
  ClipboardPaste,
  Trash2,
  Sparkles,
  BookOpen,
  Briefcase,
  Code,
  PenTool,
  Globe,
  FileText,
  AlertCircle,
} from 'lucide-react';

interface ScanInputProps {
  text: string;
  onChangeText: (text: string) => void;
  onScan: () => void;
  isScanning: boolean;
  mode: ScanMode;
  onChangeMode: (mode: ScanMode) => void;
}

export const ScanInput: React.FC<ScanInputProps> = ({
  text,
  onChangeText,
  onScan,
  isScanning,
  mode,
  onChangeMode,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedSampleId, setSelectedSampleId] = useState<string>('');
  const [dragOver, setDragOver] = useState<boolean>(false);

  // Compute live word and character counts
  const trimmed = text.trim();
  const wordCount = trimmed ? trimmed.split(/\s+/).filter(Boolean).length : 0;
  const charCount = text.length;
  const estimatedSentences = trimmed
    ? trimmed.split(/(?<=[.?!])\s+(?=[A-Z0-9"'])/).filter(Boolean).length
    : 0;
  const readingTimeMin = Math.ceil(wordCount / 200);

  const isTooShort = wordCount > 0 && wordCount < 15;

  const handleSelectSample = (sample: SampleText) => {
    setSelectedSampleId(sample.id);
    onChangeText(sample.text);
  };

  const handlePaste = async () => {
    try {
      const clipText = await navigator.clipboard.readText();
      if (clipText) {
        onChangeText(clipText);
        setSelectedSampleId('');
      }
    } catch (err) {
      console.warn('Clipboard access denied:', err);
    }
  };

  const handleClear = () => {
    onChangeText('');
    setSelectedSampleId('');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        onChangeText(content);
        setSelectedSampleId('');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (content) {
          onChangeText(content);
          setSelectedSampleId('');
        }
      };
      reader.readAsText(file);
    }
  };

  const modes: { id: ScanMode; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'general', label: 'General / Web', icon: Globe },
    { id: 'academic', label: 'Academic / Essay', icon: BookOpen },
    { id: 'professional', label: 'Business & Docs', icon: Briefcase },
    { id: 'technical', label: 'Code & Tech', icon: Code },
    { id: 'creative', label: 'Creative / Prose', icon: PenTool },
  ];

  return (
    <div className="space-y-4">
      {/* Mode Selection Pills */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl bg-slate-900/90 border border-slate-800">
          {modes.map((m) => {
            const Icon = m.icon;
            const isActive = mode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => onChangeMode(m.id)}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                  isActive
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{m.label}</span>
              </button>
            );
          })}
        </div>

        {/* Quick Sample Selector Dropdown/Chips */}
        <div className="flex items-center space-x-2">
          <span className="text-[11px] font-mono text-slate-400 hidden sm:inline">
            Load Sample:
          </span>
          <div className="flex items-center space-x-1 overflow-x-auto max-w-xs sm:max-w-none pb-1 sm:pb-0">
            {SAMPLE_TEXTS.slice(0, 3).map((sample) => (
              <button
                key={sample.id}
                onClick={() => handleSelectSample(sample)}
                className={`text-[11px] px-2.5 py-1 rounded-lg border font-mono transition-all whitespace-nowrap cursor-pointer ${
                  selectedSampleId === sample.id
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                    : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border-slate-800 hover:bg-slate-800'
                }`}
                title={sample.description}
              >
                {sample.category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Textarea Container */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        className={`cyber-card rounded-2xl p-4 sm:p-5 bg-slate-950/70 border transition-all duration-300 relative ${
          dragOver
            ? 'border-cyan-400 shadow-xl shadow-cyan-500/20 bg-slate-900/90'
            : 'border-slate-800 focus-within:border-cyan-500/40'
        }`}
      >
        {/* Radar Scanning Line Overlay (when scanning) */}
        {isScanning && (
          <div className="absolute inset-0 pointer-events-none rounded-2xl overflow-hidden z-20">
            <div className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-scan" />
            <div className="absolute inset-0 bg-cyan-950/20 backdrop-blur-[1px]" />
          </div>
        )}

        {/* Toolbar Header */}
        <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-800/80 text-xs text-slate-400">
          <div className="flex items-center space-x-3">
            <button
              onClick={handlePaste}
              className="flex items-center space-x-1 hover:text-cyan-400 transition-colors cursor-pointer"
              title="Paste from clipboard"
            >
              <ClipboardPaste className="w-3.5 h-3.5" />
              <span>Paste</span>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center space-x-1 hover:text-cyan-400 transition-colors cursor-pointer"
              title="Upload text or markdown file"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload (.txt, .md)</span>
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept=".txt,.md,.text"
              className="hidden"
            />

            {text && (
              <button
                onClick={handleClear}
                className="flex items-center space-x-1 hover:text-rose-400 transition-colors cursor-pointer"
                title="Clear text"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            )}
          </div>

          <div className="flex items-center space-x-3 font-mono text-[11px] text-slate-400">
            <span>{wordCount} words</span>
            <span className="hidden sm:inline">•</span>
            <span className="hidden sm:inline">{charCount} chars</span>
            <span className="hidden md:inline">•</span>
            <span className="hidden md:inline">~{readingTimeMin}m read</span>
          </div>
        </div>

        {/* Text Input Area */}
        <textarea
          value={text}
          onChange={(e) => {
            onChangeText(e.target.value);
            if (selectedSampleId) setSelectedSampleId('');
          }}
          placeholder="Paste or write your text here to run DeepScan AI forensics... (e.g. essays, articles, professional reports, code explanations, or customer correspondence)"
          className="w-full h-48 sm:h-60 bg-transparent text-slate-200 placeholder-slate-600 text-sm sm:text-base leading-relaxed font-sans resize-none focus:outline-none"
        />

        {/* Warning if text is too short */}
        {isTooShort && (
          <div className="mt-2 flex items-center space-x-1.5 text-xs text-amber-400/90 font-mono">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>Recommended minimum: 25+ words for robust statistical perplexity and cadence sampling.</span>
          </div>
        )}

        {/* Footer Actions */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-slate-400 font-mono">
            <span>Engine: </span>
            <span className="text-cyan-400 font-semibold">Perplexity & N-Gram Burstiness v3.8</span>
          </div>

          <button
            onClick={onScan}
            disabled={isScanning || !trimmed}
            className={`flex items-center space-x-2 px-6 py-2.5 rounded-xl font-semibold text-sm transition-all duration-300 cursor-pointer shadow-lg ${
              isScanning
                ? 'bg-slate-800 text-cyan-300 cursor-not-allowed border border-cyan-500/40'
                : !trimmed
                ? 'bg-slate-800/60 text-slate-500 cursor-not-allowed border border-slate-800'
                : 'bg-gradient-to-r from-cyan-500 via-sky-500 to-indigo-600 hover:from-cyan-400 hover:via-sky-400 hover:to-indigo-500 text-white shadow-cyan-500/25 hover:shadow-cyan-500/40 transform hover:-translate-y-0.5'
            }`}
          >
            {isScanning ? (
              <>
                <div className="relative w-4 h-4">
                  <div className="w-4 h-4 rounded-full border-2 border-cyan-400/30 border-t-cyan-400 animate-spin" />
                </div>
                <span>Executing Deep Forensic Scan...</span>
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                <span>Deep Scan Content</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
