import React, { useState, useRef } from 'react';
import { ImageAnalysisResult, VisualArtifact } from '../types';
import {
  Image as ImageIcon,
  Upload,
  Search,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  ZoomIn,
  RefreshCw,
  Eye,
  Sliders,
  CheckCircle2,
  Sparkles,
  Info,
} from 'lucide-react';

// Sample presets for instant testing
const SAMPLE_IMAGES = [
  {
    id: 'sample-flux-ai',
    title: 'Photorealistic AI Portrait',
    category: 'Flux.1 / Midjourney',
    expected: '94% AI',
    description: 'Hyper-detailed face with waxy pore smoothing and subtle pupil catchlight asymmetry.',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80',
    mockAi: 95,
  },
  {
    id: 'sample-real-camera',
    title: 'Authentic DSLR Street Photo',
    category: 'Camera Capture',
    expected: '4% AI (Real)',
    description: 'Natural optical depth-of-field, authentic sensor ISO noise, and organic skin blemishes.',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80',
    mockAi: 6,
  },
  {
    id: 'sample-dalle-art',
    title: 'Cyberpunk Concept Art',
    category: 'DALL-E 3 Synthetic',
    expected: '98% AI',
    description: 'Stylized digital illustration with latent diffusion texture repetitions and blurred background hands.',
    url: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80',
    mockAi: 98,
  },
];

interface ImageForensicsViewProps {
  onSaveToHistory: (result: ImageAnalysisResult) => void;
}

export const ImageForensicsView: React.FC<ImageForensicsViewProps> = ({ onSaveToHistory }) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(SAMPLE_IMAGES[0].url);
  const [imageName, setImageName] = useState<string>(SAMPLE_IMAGES[0].title);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [result, setResult] = useState<ImageAnalysisResult | null>(null);
  const [showArtifactOverlay, setShowArtifactOverlay] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImageName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setSelectedImage(dataUrl);
      setResult(null);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleRunScan = async (imgUrlToScan?: string, nameToScan?: string) => {
    const targetUrl = imgUrlToScan || selectedImage;
    const targetName = nameToScan || imageName;
    if (!targetUrl) return;

    setIsScanning(true);
    setError(null);

    try {
      const res = await fetch('/api/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: targetUrl,
          imageName: targetName,
        }),
      });

      if (!res.ok) {
        throw new Error('Failed to complete image forensic analysis.');
      }

      const data: ImageAnalysisResult = await res.json();
      setResult(data);
      onSaveToHistory(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error running image forensics.');
    } finally {
      setIsScanning(false);
    }
  };

  const isHighAi = (result?.overallAiProbability ?? 0) >= 70;
  const isModerateAi = (result?.overallAiProbability ?? 0) >= 35 && (result?.overallAiProbability ?? 0) < 70;

  return (
    <div className="space-y-8">
      {/* Introduction Header */}
      <div className="text-center space-y-2 max-w-3xl mx-auto">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono">
          <ImageIcon className="w-3.5 h-3.5" />
          <span>Computer Vision & Latent Diffusion Forensics</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
          Detect AI-Generated Images & Deepfakes
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          Scan photos, digital art, portraits, and product renders for diffusion artifacts,
          anatomical inconsistencies, waxy epidermal smoothing, and optical lighting physics.
        </p>
      </div>

      {/* Preset Samples Selector */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <span className="text-xs font-semibold text-slate-400 flex items-center space-x-1">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Quick Benchmark Presets:</span>
        </span>
        <div className="flex flex-wrap items-center gap-2">
          {SAMPLE_IMAGES.map((sample) => (
            <button
              key={sample.id}
              onClick={() => {
                setSelectedImage(sample.url);
                setImageName(sample.title);
                setResult(null);
                handleRunScan(sample.url, sample.title);
              }}
              className="flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all cursor-pointer"
            >
              <span>{sample.title}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-900 text-cyan-400 border border-slate-800">
                {sample.expected}
              </span>
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {error}
        </div>
      )}

      {/* Main Upload / Viewer Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Image Preview / Dropzone */}
        <div className="lg:col-span-6 space-y-4">
          <div className="cyber-card rounded-2xl p-4 bg-slate-950/80 border border-slate-800 relative overflow-hidden group">
            {selectedImage ? (
              <div className="relative rounded-xl overflow-hidden bg-black flex items-center justify-center min-h-[340px] max-h-[460px]">
                <img
                  src={selectedImage}
                  alt="Forensic candidate"
                  className="max-h-[460px] w-auto object-contain rounded-lg transition-transform duration-300"
                />

                {/* Scanning Radar Line */}
                {isScanning && (
                  <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
                    <div className="absolute left-0 right-0 h-1 bg-cyan-400 shadow-[0_0_15px_#22d3ee] animate-scan" />
                    <div className="absolute inset-0 bg-cyan-950/25 backdrop-blur-[1px]" />
                  </div>
                )}

                {/* Visual Artifact Highlight Banners */}
                {result && showArtifactOverlay && result.artifacts.length > 0 && (
                  <div className="absolute bottom-3 left-3 right-3 z-20 bg-slate-950/85 backdrop-blur-md p-2.5 rounded-xl border border-rose-500/40 text-xs text-rose-200 flex items-center justify-between shadow-xl">
                    <div className="flex items-center space-x-2">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span className="font-semibold">{result.artifacts[0].region}:</span>
                      <span className="line-clamp-1 text-slate-300">{result.artifacts[0].description}</span>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="h-80 border-2 border-dashed border-slate-700 hover:border-cyan-500/50 rounded-xl flex flex-col items-center justify-center text-center p-6 cursor-pointer bg-slate-900/40 transition-colors"
              >
                <Upload className="w-10 h-10 text-cyan-400 mb-2 opacity-80" />
                <span className="text-sm font-semibold text-slate-200">
                  Upload an image to detect AI artifacts
                </span>
                <span className="text-xs text-slate-400 mt-1">
                  Supports JPG, PNG, WEBP, and AVIF up to 15MB
                </span>
              </div>
            )}

            {/* Toolbar under preview */}
            <div className="mt-3 flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800">
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center space-x-1 hover:text-cyan-400 cursor-pointer transition-colors"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Choose Another Image</span>
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="image/*"
                  className="hidden"
                />

                {result && (
                  <button
                    onClick={() => setShowArtifactOverlay(!showArtifactOverlay)}
                    className={`flex items-center space-x-1 cursor-pointer transition-colors ${
                      showArtifactOverlay ? 'text-cyan-400 font-semibold' : 'text-slate-400'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Overlay {showArtifactOverlay ? 'On' : 'Off'}</span>
                  </button>
                )}
              </div>

              <span className="font-mono text-[11px] truncate max-w-[150px]">{imageName}</span>
            </div>
          </div>

          {/* Primary Action Button */}
          <button
            onClick={() => handleRunScan()}
            disabled={isScanning || !selectedImage}
            className="w-full py-3 rounded-xl font-semibold text-sm bg-gradient-to-r from-cyan-500 via-sky-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 disabled:opacity-50 text-white shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            {isScanning ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Running Computer Vision Decomposition...</span>
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                <span>Deep Scan Image</span>
              </>
            )}
          </button>
        </div>

        {/* Right Column: Forensic Results Dashboard */}
        <div className="lg:col-span-6 space-y-5">
          {result ? (
            <div className="space-y-5 animate-in fade-in duration-300">
              {/* Verdict Banner */}
              <div className="cyber-card rounded-2xl p-5 bg-slate-900/70 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center space-x-3">
                  <div
                    className={`p-3 rounded-xl font-mono text-xl font-extrabold ${
                      isHighAi
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                        : isModerateAi
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {result.overallAiProbability}%
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-bold text-white">{result.verdict}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                        {result.confidenceLevel} Confidence
                      </span>
                    </div>
                    <p className="text-xs text-cyan-400 font-mono mt-0.5">
                      Suspected Source: {result.suspectedGenerator}
                    </p>
                  </div>
                </div>
              </div>

              {/* Summary card */}
              <div className="cyber-card rounded-2xl p-4 bg-slate-900/50 border border-slate-800 text-xs text-slate-300 leading-relaxed font-sans">
                {result.summary}
              </div>

              {/* Photometric Metrics Grid */}
              <div className="cyber-card rounded-2xl p-5 bg-slate-900/60 border border-slate-800 space-y-3">
                <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                  <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Photometric Coherence Telemetry</span>
                </h4>

                <div className="space-y-2.5 text-xs">
                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Anatomical & Biological Structure</span>
                      <span className="font-mono text-cyan-400">
                        {result.photometricMetrics.anatomicalConsistency}/100
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-rose-500 to-emerald-400"
                        style={{ width: `${result.photometricMetrics.anatomicalConsistency}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Texture & Epidermal Pore Coherence</span>
                      <span className="font-mono text-cyan-400">
                        {result.photometricMetrics.texturePoreCoherence}/100
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-rose-500 to-emerald-400"
                        style={{ width: `${result.photometricMetrics.texturePoreCoherence}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Lighting & Shadow Vector Physics</span>
                      <span className="font-mono text-cyan-400">
                        {result.photometricMetrics.lightingShadowPhysics}/100
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-rose-500 to-emerald-400"
                        style={{ width: `${result.photometricMetrics.lightingShadowPhysics}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Sensor Noise vs Synthetic Diffusion Grain</span>
                      <span className="font-mono text-cyan-400">
                        {result.photometricMetrics.noiseFingerprint}/100
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-rose-500 to-emerald-400"
                        style={{ width: `${result.photometricMetrics.noiseFingerprint}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Detected Visual Artifacts */}
              {result.artifacts.length > 0 && (
                <div className="cyber-card rounded-2xl p-5 bg-slate-900/60 border border-slate-800 space-y-3">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400">
                    Flagged Visual Anomalies
                  </h4>
                  <div className="space-y-2">
                    {result.artifacts.map((artifact, aIdx) => (
                      <div
                        key={aIdx}
                        className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start space-x-3 text-xs"
                      >
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono shrink-0 font-bold ${
                            artifact.severity === 'High'
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          }`}
                        >
                          {artifact.severity}
                        </span>
                        <div>
                          <span className="font-semibold text-slate-200 block mb-0.5">
                            {artifact.region}
                          </span>
                          <span className="text-slate-400">{artifact.description}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="cyber-card rounded-2xl p-8 bg-slate-900/30 border border-slate-800 text-center space-y-3">
              <Eye className="w-10 h-10 text-slate-600 mx-auto" />
              <h4 className="text-sm font-semibold text-slate-200">Awaiting Image Scan</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Select a preset or upload an image, then click "Deep Scan Image" to decompose latent
                diffusion layers, sensor noise, and facial anatomical physics.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
