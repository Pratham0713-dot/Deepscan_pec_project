import React, { useState, useRef, useEffect } from 'react';
import { AudioAnalysisResult, AudioTimeRegion } from '../types';
import {
  Mic,
  MicOff,
  Upload,
  Play,
  Pause,
  Search,
  Volume2,
  RefreshCw,
  Sparkles,
  Activity,
  Layers,
  AlertTriangle,
  Radio,
  FileAudio,
} from 'lucide-react';

const SAMPLE_AUDIO_PRESETS = [
  {
    id: 'sample-elevenlabs',
    title: 'ElevenLabs AI Voice Clone',
    category: 'Synthetic Clone',
    expected: '92% AI',
    description: 'AI synthetic narration with missing subglottal breathing pauses and neural vocoder metallic overtone.',
    duration: 8,
  },
  {
    id: 'sample-human-podcast',
    title: 'Authentic Human Podcast Clip',
    category: 'Human Vocal',
    expected: '14% AI (Human)',
    description: 'Dynamic conversational pitch inflection, natural inhalation micro-rests, and organic room acoustics.',
    duration: 12,
  },
  {
    id: 'sample-openai-tts',
    title: 'OpenAI TTS Shimmer Voice',
    category: 'Neural TTS',
    expected: '96% AI',
    description: 'Ultra-smooth robotic prosody with flat F0 fundamental pitch contour and synthetic sibilant transitions.',
    duration: 6,
  },
];

interface AudioForensicsViewProps {
  onSaveToHistory: (result: AudioAnalysisResult) => void;
}

export const AudioForensicsView: React.FC<AudioForensicsViewProps> = ({ onSaveToHistory }) => {
  const [audioName, setAudioName] = useState<string>(SAMPLE_AUDIO_PRESETS[0].title);
  const [audioDataUrl, setAudioDataUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [result, setResult] = useState<AudioAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<number | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Simulated or real waveform drawing loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let phase = 0;
    const drawWave = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.width;
      const height = canvas.height;
      const bars = 48;
      const barWidth = width / bars;

      for (let i = 0; i < bars; i++) {
        let amp = 0.2;
        if (isPlaying || isRecording) {
          amp = Math.sin((i * 0.3) + phase) * 0.4 + Math.cos((i * 0.1) - phase) * 0.4 + 0.3;
        } else {
          amp = Math.sin(i * 0.25) * 0.15 + 0.2;
        }
        const barHeight = Math.max(6, Math.abs(amp) * height * 0.85);
        const x = i * barWidth;
        const y = (height - barHeight) / 2;

        ctx.fillStyle = isRecording
          ? '#f43f5e'
          : isPlaying
          ? '#22d3ee'
          : '#334155';
        ctx.beginPath();
        ctx.roundRect(x + 1, y, barWidth - 2, barHeight, 2);
        ctx.fill();
      }

      phase += (isPlaying || isRecording) ? 0.08 : 0.01;
      animId = requestAnimationFrame(drawWave);
    };

    drawWave();
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, isRecording]);

  // Handle Live Mic Recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/mp3' });
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = reader.result as string;
          setAudioDataUrl(base64);
          setAudioName(`Live_Voice_Capture_${new Date().toLocaleTimeString().replace(/:/g, '-')}.mp3`);
        };
        reader.readAsDataURL(audioBlob);

        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);
      setResult(null);

      recordTimerRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.warn('Microphone access denied:', err);
      setError('Microphone access was denied or is not supported. Please upload an audio file instead.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (recordTimerRef.current) clearInterval(recordTimerRef.current);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAudioName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      setAudioDataUrl(event.target?.result as string);
      setResult(null);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleRunScan = async (nameOverride?: string) => {
    setIsScanning(true);
    setError(null);
    const name = nameOverride || audioName;

    try {
      const res = await fetch('/api/analyze-audio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audioBase64: audioDataUrl || 'UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=', // fallback dummy header
          audioName: name,
          duration: recordingSeconds || 8,
        }),
      });

      if (!res.ok) {
        throw new Error('Audio forensic analysis failed.');
      }

      const data: AudioAnalysisResult = await res.json();
      setResult(data);
      onSaveToHistory(data);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error executing audio analysis.');
    } finally {
      setIsScanning(false);
    }
  };

  const isHighAi = (result?.overallAiProbability ?? 0) >= 70;
  const isModerateAi = (result?.overallAiProbability ?? 0) >= 35 && (result?.overallAiProbability ?? 0) < 70;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-2 max-w-3xl mx-auto">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono">
          <Radio className="w-3.5 h-3.5" />
          <span>Acoustic Waveform & Deepfake Voice Cloning Forensics</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
          Detect Synthetic AI Voices & Voice Clones
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          Analyze vocal tracks for ElevenLabs, OpenAI Voice, Bark, and RVC deepfake synthesis.
          Inspects subglottal breath dynamics, metallic vocoder frequencies, and pitch micro-jitter.
        </p>
      </div>

      {/* Preset Benchmarks */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <span className="text-xs font-semibold text-slate-400 flex items-center space-x-1">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Synthetic Voice Benchmarks:</span>
        </span>
        <div className="flex flex-wrap items-center gap-2">
          {SAMPLE_AUDIO_PRESETS.map((sample) => (
            <button
              key={sample.id}
              onClick={() => {
                setAudioName(sample.title);
                setResult(null);
                handleRunScan(sample.title);
              }}
              className="flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all cursor-pointer"
            >
              <span>{sample.title}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-900 text-cyan-400 border border-slate-800">
                {sample.expected}
              </span>
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {error}
        </div>
      )}

      {/* Audio Console Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Waveform Studio & Recorder */}
        <div className="lg:col-span-6 space-y-4">
          <div className="cyber-card rounded-2xl p-5 bg-slate-950/80 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono uppercase tracking-wider flex items-center space-x-1.5">
                <FileAudio className="w-4 h-4 text-cyan-400" />
                <span>Acoustic Frequency Monitor</span>
              </span>
              <span className="font-mono text-[11px] text-cyan-400 truncate max-w-[180px]">
                {audioName}
              </span>
            </div>

            {/* Interactive Canvas Waveform */}
            <div className="h-32 bg-slate-900/60 rounded-xl border border-slate-800/80 p-2 flex items-center justify-center relative overflow-hidden">
              <canvas
                ref={canvasRef}
                width={480}
                height={120}
                className="w-full h-full"
              />
              {isRecording && (
                <div className="absolute top-3 right-3 flex items-center space-x-1.5 bg-rose-500/20 text-rose-400 px-2.5 py-1 rounded-full text-xs font-mono border border-rose-500/40 animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-rose-500" />
                  <span>Recording {recordingSeconds}s</span>
                </div>
              )}
            </div>

            {/* Player & Controls Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex items-center space-x-2">
                {audioDataUrl && (
                  <button
                    onClick={() => {
                      if (!audioPlayerRef.current) return;
                      if (isPlaying) {
                        audioPlayerRef.current.pause();
                        setIsPlaying(false);
                      } else {
                        audioPlayerRef.current.play();
                        setIsPlaying(true);
                      }
                    }}
                    className="p-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white transition-all cursor-pointer shadow-md"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                )}
                {audioDataUrl && (
                  <audio
                    ref={audioPlayerRef}
                    src={audioDataUrl}
                    onEnded={() => setIsPlaying(false)}
                    className="hidden"
                  />
                )}

                {/* Microphone Record Toggle */}
                <button
                  onClick={isRecording ? stopRecording : startRecording}
                  className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer shadow-sm ${
                    isRecording
                      ? 'bg-rose-600 hover:bg-rose-500 text-white animate-pulse'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  {isRecording ? (
                    <>
                      <MicOff className="w-3.5 h-3.5" />
                      <span>Stop Recording</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Record Speech</span>
                    </>
                  )}
                </button>

                {/* File Upload Button */}
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-slate-400" />
                  <span>Upload Audio</span>
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="audio/*"
                  className="hidden"
                />
              </div>

              <span className="text-[11px] font-mono text-slate-500">
                MP3, WAV, M4A, OGG
              </span>
            </div>
          </div>

          {/* Primary Action Button */}
          <button
            onClick={() => handleRunScan()}
            disabled={isScanning || isRecording}
            className="w-full py-3 rounded-xl font-semibold text-sm bg-gradient-to-r from-cyan-500 via-sky-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 disabled:opacity-50 text-white shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            {isScanning ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Decomposing Vocal Formants & Harmonics...</span>
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                <span>Deep Scan Audio Sample</span>
              </>
            )}
          </button>
        </div>

        {/* Right Column: Audio Forensic Metrics */}
        <div className="lg:col-span-6 space-y-5">
          {result ? (
            <div className="space-y-5 animate-in fade-in duration-300">
              {/* Verdict Banner */}
              <div className="cyber-card rounded-2xl p-5 bg-slate-900/70 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center space-x-3">
                  <div
                    className={`p-3 rounded-xl font-mono text-xl font-extrabold ${
                      isHighAi
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                        : isModerateAi
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {result.overallAiProbability}%
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-bold text-white">{result.verdict}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                        {result.confidenceLevel} Confidence
                      </span>
                    </div>
                    <p className="text-xs text-cyan-400 font-mono mt-0.5">
                      Suspected Source: {result.suspectedSynthesizer}
                    </p>
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div className="cyber-card rounded-2xl p-4 bg-slate-900/50 border border-slate-800 text-xs text-slate-300 leading-relaxed font-sans">
                {result.summary}
              </div>

              {/* Spectral Telemetry */}
              <div className="cyber-card rounded-2xl p-5 bg-slate-900/60 border border-slate-800 space-y-3">
                <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Spectral & Biomechanical Vocal Metrics</span>
                </h4>

                <div className="space-y-2.5 text-xs">
                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Prosody & Emotional Intonation Naturalness</span>
                      <span className="font-mono text-cyan-400">
                        {result.spectralMetrics.prosodyNaturalness}/100
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-rose-500 to-emerald-400"
                        style={{ width: `${result.spectralMetrics.prosodyNaturalness}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Inhalation & Subglottal Respiration Evidence</span>
                      <span className="font-mono text-cyan-400">
                        {result.spectralMetrics.respiratoryBreathingEvidence}/100
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-rose-500 to-emerald-400"
                        style={{ width: `${result.spectralMetrics.respiratoryBreathingEvidence}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Pitch Micro-Variation (Organic Jitter & Shimmer)</span>
                      <span className="font-mono text-cyan-400">
                        {result.spectralMetrics.pitchMicroVariation}/100
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-rose-500 to-emerald-400"
                        style={{ width: `${result.spectralMetrics.pitchMicroVariation}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span>Metallic Vocoder Phase Ringing (AI Artifact)</span>
                      <span className="font-mono text-rose-400">
                        {result.spectralMetrics.metallicPhaseArtifacts}%
                      </span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-rose-500"
                        style={{ width: `${result.spectralMetrics.metallicPhaseArtifacts}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Time Regions Breakdown */}
              {result.timeRegions.length > 0 && (
                <div className="cyber-card rounded-2xl p-5 bg-slate-900/60 border border-slate-800 space-y-3">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400">
                    Temporal Timeline Classification
                  </h4>
                  <div className="space-y-2">
                    {result.timeRegions.map((region, rIdx) => (
                      <div
                        key={rIdx}
                        className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-start space-x-3 text-xs"
                      >
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-cyan-400 shrink-0 border border-slate-700">
                          {region.timeStartSec.toFixed(1)}s - {region.timeEndSec.toFixed(1)}s
                        </span>
                        <div>
                          <div className="flex items-center space-x-2 mb-0.5">
                            <span className="font-semibold text-slate-200">
                              {region.classification === 'synthetic_voice'
                                ? 'Synthetic Voice Signature'
                                : region.classification === 'cloned'
                                ? 'Neural Voice Clone'
                                : 'Organic Human Speech'}
                            </span>
                            <span
                              className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                                region.aiProbability > 70
                                  ? 'text-rose-400 bg-rose-500/10'
                                  : 'text-emerald-400 bg-emerald-500/10'
                              }`}
                            >
                              {region.aiProbability}% AI
                            </span>
                          </div>
                          <p className="text-slate-400 text-[11px] leading-relaxed">{region.reason}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="cyber-card rounded-2xl p-8 bg-slate-900/30 border border-slate-800 text-center space-y-3">
              <Radio className="w-10 h-10 text-slate-600 mx-auto" />
              <h4 className="text-sm font-semibold text-slate-200">Awaiting Audio Scan</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Record live speech from your microphone or upload an audio file to evaluate
                prosodic naturalness, vocal tract physics, and synthetic vocoder artifacts.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
