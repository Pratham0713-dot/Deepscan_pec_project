import React, { useState } from 'react';
import { SentenceItem } from '../types';
import { Eye, Sparkles, AlertCircle, CheckCircle, RefreshCw, Copy, Check, Filter } from 'lucide-react';

interface SentenceHeatmapProps {
  sentences: SentenceItem[];
  onApplySentenceReplacement?: (oldText: string, newText: string) => void;
}

export const SentenceHeatmap: React.FC<SentenceHeatmapProps> = ({
  sentences,
  onApplySentenceReplacement,
}) => {
  const [selectedSentenceIndex, setSelectedSentenceIndex] = useState<number | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'ai' | 'mixed' | 'human'>('all');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const selectedSentence =
    selectedSentenceIndex !== null && sentences[selectedSentenceIndex]
      ? sentences[selectedSentenceIndex]
      : null;

  // Filter sentences based on selection
  const filteredSentences = sentences.filter((s) => {
    if (filterType === 'all') return true;
    if (filterType === 'ai') return s.aiProbability >= 70;
    if (filterType === 'mixed') return s.aiProbability >= 35 && s.aiProbability < 70;
    if (filterType === 'human') return s.aiProbability < 35;
    return true;
  });

  const getHighlightClass = (prob: number, isSelected: boolean) => {
    let base = 'transition-all duration-200 cursor-pointer rounded px-1 py-0.5 my-0.5 inline ';
    if (isSelected) {
      base += 'ring-2 ring-cyan-400 ring-offset-2 ring-offset-slate-900 font-medium ';
    }

    if (prob >= 75) {
      return base + 'bg-rose-500/25 hover:bg-rose-500/40 text-rose-100 border-b-2 border-rose-500';
    } else if (prob >= 50) {
      return base + 'bg-amber-500/20 hover:bg-amber-500/35 text-amber-100 border-b-2 border-amber-500';
    } else if (prob >= 25) {
      return base + 'bg-yellow-500/15 hover:bg-yellow-500/25 text-yellow-100 border-b border-yellow-500/60';
    } else {
      return base + 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-100 border-b border-emerald-500/60';
    }
  };

  const getPillBadge = (prob: number) => {
    if (prob >= 75) return { bg: 'bg-rose-500/20 text-rose-300 border-rose-500/40', label: 'AI Generated' };
    if (prob >= 50) return { bg: 'bg-amber-500/20 text-amber-300 border-amber-500/40', label: 'Likely AI' };
    if (prob >= 25) return { bg: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40', label: 'Mixed / Ambiguous' };
    return { bg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40', label: 'Organic Human' };
  };

  const handleCopy = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  // Count stats
  const highAiCount = sentences.filter((s) => s.aiProbability >= 70).length;
  const mixedCount = sentences.filter((s) => s.aiProbability >= 35 && s.aiProbability < 70).length;
  const humanCount = sentences.filter((s) => s.aiProbability < 35).length;

  return (
    <div className="space-y-6">
      {/* Legend & Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-400 flex items-center space-x-1 mr-2">
            <Filter className="w-3.5 h-3.5" />
            <span>Filter By Class:</span>
          </span>

          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
              filterType === 'all'
                ? 'bg-slate-700 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200 bg-slate-800/40'
            }`}
          >
            All Sentences ({sentences.length})
          </button>

          <button
            onClick={() => setFilterType('ai')}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-all ${
              filterType === 'ai'
                ? 'bg-rose-500/25 text-rose-300 border border-rose-500/50 font-semibold'
                : 'text-slate-400 hover:text-rose-300 bg-slate-800/40'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <span>AI Risk ({highAiCount})</span>
          </button>

          <button
            onClick={() => setFilterType('mixed')}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-all ${
              filterType === 'mixed'
                ? 'bg-amber-500/25 text-amber-300 border border-amber-500/50 font-semibold'
                : 'text-slate-400 hover:text-amber-300 bg-slate-800/40'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            <span>Mixed ({mixedCount})</span>
          </button>

          <button
            onClick={() => setFilterType('human')}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-all ${
              filterType === 'human'
                ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/50 font-semibold'
                : 'text-slate-400 hover:text-emerald-300 bg-slate-800/40'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Human ({humanCount})</span>
          </button>
        </div>

        <div className="text-xs text-slate-400 font-mono flex items-center space-x-1">
          <Eye className="w-3.5 h-3.5 text-cyan-400" />
          <span>Click any sentence to inspect forensic telemetry</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Text Heatmap Inspector */}
        <div className={`${selectedSentence ? 'lg:col-span-7' : 'lg:col-span-12'} transition-all duration-300`}>
          <div className="cyber-card rounded-2xl p-6 bg-slate-950/70 border border-slate-800 text-slate-200 leading-relaxed text-base min-h-[360px]">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800/80">
              <span className="text-xs uppercase font-mono tracking-wider text-slate-400">
                Interactive Document Heatmap
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {filteredSentences.length} sentences shown
              </span>
            </div>

            <div className="space-y-3 font-sans">
              {sentences.map((sentence, idx) => {
                const isSelected = selectedSentenceIndex === idx;
                const matchesFilter =
                  filterType === 'all' ||
                  (filterType === 'ai' && sentence.aiProbability >= 70) ||
                  (filterType === 'mixed' && sentence.aiProbability >= 35 && sentence.aiProbability < 70) ||
                  (filterType === 'human' && sentence.aiProbability < 35);

                return (
                  <span
                    key={idx}
                    onClick={() => setSelectedSentenceIndex(isSelected ? null : idx)}
                    className={`${getHighlightClass(sentence.aiProbability, isSelected)} ${
                      !matchesFilter ? 'opacity-30' : 'opacity-100'
                    }`}
                    title={`AI Prob: ${sentence.aiProbability}% - Click for forensic breakdown`}
                  >
                    {sentence.text}{' '}
                  </span>
                );
              })}
            </div>
          </div>
        </div>

        {/* Selected Sentence Inspector Panel */}
        {selectedSentence && selectedSentenceIndex !== null && (
          <div className="lg:col-span-5 animate-in fade-in slide-in-from-right-4 duration-200">
            <div className="cyber-card rounded-2xl p-5 bg-slate-900 border border-cyan-500/30 shadow-xl space-y-4 sticky top-20">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-mono uppercase text-slate-400">Sentence #{selectedSentenceIndex + 1}</span>
                  <span
                    className={`text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full border ${
                      getPillBadge(selectedSentence.aiProbability).bg
                    }`}
                  >
                    {selectedSentence.aiProbability}% AI Probability
                  </span>
                </div>
                <button
                  onClick={() => setSelectedSentenceIndex(null)}
                  className="text-xs text-slate-400 hover:text-white p-1 rounded"
                >
                  ✕
                </button>
              </div>

              {/* Analyzed Sentence Text */}
              <div>
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block mb-1">
                  Selected Sentence
                </span>
                <p className="text-sm text-slate-200 bg-slate-950 p-3 rounded-lg border border-slate-800 font-sans italic">
                  "{selectedSentence.text}"
                </p>
              </div>

              {/* Diagnostic Rationale */}
              <div>
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block mb-1">
                  Forensic Diagnostic
                </span>
                <p className="text-xs text-slate-300 bg-slate-800/40 p-3 rounded-lg border border-slate-700/60 leading-relaxed">
                  {selectedSentence.reason}
                </p>
              </div>

              {/* Flagged Tokens */}
              {selectedSentence.telltaleTokens && selectedSentence.telltaleTokens.length > 0 && (
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-wider text-rose-400 block mb-1.5 flex items-center space-x-1">
                    <AlertCircle className="w-3 h-3" />
                    <span>Flagged AI Signatures / Tropes</span>
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedSentence.telltaleTokens.map((token, tIdx) => (
                      <span
                        key={tIdx}
                        className="px-2 py-0.5 rounded text-xs font-mono bg-rose-500/20 text-rose-300 border border-rose-500/40"
                      >
                        "{token}"
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Humanize Suggestion */}
              {selectedSentence.humanizeSuggestion && (
                <div className="pt-2 border-t border-slate-800">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-emerald-400 block mb-1.5 flex items-center space-x-1">
                    <Sparkles className="w-3 h-3" />
                    <span>Natural Human Rewrite</span>
                  </span>
                  <div className="bg-emerald-950/30 p-3 rounded-lg border border-emerald-500/30 space-y-2">
                    <p className="text-xs text-emerald-200 font-sans">
                      {selectedSentence.humanizeSuggestion}
                    </p>
                    <div className="flex items-center space-x-2 pt-1">
                      {onApplySentenceReplacement && (
                        <button
                          onClick={() => {
                            onApplySentenceReplacement(
                              selectedSentence.text,
                              selectedSentence.humanizeSuggestion
                            );
                          }}
                          className="flex items-center space-x-1 px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium cursor-pointer transition-colors shadow-sm"
                        >
                          <RefreshCw className="w-3 h-3" />
                          <span>Apply Rewrite</span>
                        </button>
                      )}
                      <button
                        onClick={() => handleCopy(selectedSentence.humanizeSuggestion, selectedSentenceIndex)}
                        className="flex items-center space-x-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer transition-colors"
                      >
                        {copiedIndex === selectedSentenceIndex ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span className="text-emerald-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
