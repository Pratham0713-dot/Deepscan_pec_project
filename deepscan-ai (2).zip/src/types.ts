export type ScanMode = 'general' | 'academic' | 'professional' | 'technical' | 'creative';

export type ForensicModality = 'text' | 'image' | 'audio' | 'docs';

// ==================== TEXT FORENSICS TYPES ====================
export interface SentenceItem {
  text: string;
  aiProbability: number;
  classification: 'ai' | 'likely_ai' | 'mixed' | 'human';
  reason: string;
  telltaleTokens: string[];
  humanizeSuggestion: string;
}

export interface MetricScores {
  perplexityScore: number;
  perplexityLabel: string;
  burstinessScore: number;
  burstinessLabel: string;
  vocabularyEntropy: number;
  syntacticMonotony: number;
  aiWatermarkMarkers: number;
}

export interface DetectedTrope {
  phrase: string;
  category: string;
  explanation: string;
  occurrences: number;
}

export interface WritingStyleAnalysis {
  tone: string;
  readingGradeLevel: string;
  averageSentenceLength: number;
  emotionalVariance: string;
}

export interface AlgorithmicStats {
  sentenceCount: number;
  wordCount: number;
  avgSentenceLength: number;
  burstinessScore: number;
  lexicalDiversity: number;
  sentenceLengths: number[];
}

export interface AnalysisResult {
  id: string;
  timestamp: string;
  text: string;
  mode: ScanMode;
  overallAiProbability: number;
  overallHumanProbability: number;
  confidenceLevel: 'High' | 'Medium' | 'Low';
  verdict: string;
  summary: string;
  metrics: MetricScores;
  sentences: SentenceItem[];
  detectedAiTropes: DetectedTrope[];
  writingStyleAnalysis: WritingStyleAnalysis;
  actionableRecommendations: string[];
  algorithmicStats?: AlgorithmicStats;
}

// ==================== IMAGE FORENSICS TYPES ====================
export interface VisualArtifact {
  region: string;
  severity: 'High' | 'Medium' | 'Low';
  description: string;
  coordinates?: { x: number; y: number; width: number; height: number };
}

export interface PhotometricMetrics {
  anatomicalConsistency: number; // 0-100 (100 = perfect human anatomy)
  texturePoreCoherence: number; // 0-100 (low = waxy airbrushed AI skin/surfaces)
  lightingShadowPhysics: number; // 0-100 (consistency of light sources)
  noiseFingerprint: number; // 0-100 (sensor grain vs synthetic diffusion noise)
  exifIntegrity: number; // 0-100 (presence of authentic camera/sensor tags)
}

export interface ImageAnalysisResult {
  id: string;
  timestamp: string;
  imageUrl: string;
  imageName: string;
  overallAiProbability: number;
  overallHumanProbability: number;
  confidenceLevel: 'High' | 'Medium' | 'Low';
  verdict: string;
  suspectedGenerator: string; // e.g. "Midjourney v6", "Flux.1", "DALL-E 3", "Stable Diffusion XL", "Real Camera Capture"
  summary: string;
  photometricMetrics: PhotometricMetrics;
  artifacts: VisualArtifact[];
  exifDetails: {
    cameraModel?: string;
    lens?: string;
    dimensions: string;
    colorSpace: string;
    hasSyntheticNoisePattern: boolean;
  };
  recommendations: string[];
}

// ==================== AUDIO FORENSICS TYPES ====================
export interface SpectralMetrics {
  prosodyNaturalness: number; // Intonation & human inflection
  respiratoryBreathingEvidence: number; // Organic breath sounds & vocal micro-rests
  spectralContinuity: number; // Continuity of vocal harmonics
  metallicPhaseArtifacts: number; // Synthetic vocoder frequency ringing
  pitchMicroVariation: number; // Natural vocal jitter and shimmer
}

export interface AudioTimeRegion {
  timeStartSec: number;
  timeEndSec: number;
  aiProbability: number;
  classification: 'synthetic_voice' | 'cloned' | 'human_organic';
  reason: string;
}

export interface AudioAnalysisResult {
  id: string;
  timestamp: string;
  audioName: string;
  audioDurationSec: number;
  overallAiProbability: number;
  overallHumanProbability: number;
  confidenceLevel: 'High' | 'Medium' | 'Low';
  verdict: string;
  suspectedSynthesizer: string; // e.g. "ElevenLabs PrimeVoice", "OpenAI TTS", "Bark / RVC Clone", "Authentic Human Voice"
  summary: string;
  spectralMetrics: SpectralMetrics;
  timeRegions: AudioTimeRegion[];
  acousticFeatures: {
    averagePitchHz: number;
    sampleRateKhz: number;
    dynamicRangeDb: number;
    backgroundAmbienceType: string;
  };
  recommendations: string[];
}

// ==================== DOCUMENT FORENSICS TYPES ====================
export interface DocumentSectionAnalysis {
  title: string;
  pageNumber: number;
  wordCount: number;
  aiProbability: number;
  status: 'Flagged High AI' | 'Mixed Origin' | 'Authentic Human';
}

export interface DocumentAnalysisResult {
  id: string;
  timestamp: string;
  documentName: string;
  fileSizeKb: number;
  pageCount: number;
  totalWords: number;
  overallAiProbability: number;
  overallHumanProbability: number;
  confidenceLevel: 'High' | 'Medium' | 'Low';
  verdict: string;
  summary: string;
  sections: DocumentSectionAnalysis[];
  citationAudit: {
    totalCitationsFound: number;
    flaggedHallucinatedCitations: number;
    citationConfidence: string;
    notes: string;
  };
  metadataForensics: {
    creatorApplication: string;
    revisionCount: number;
    editingTimeMinutes: number;
    anomalyDetected: boolean;
  };
  textResult: AnalysisResult;
}

// ==================== UNIVERSAL HISTORY ITEM ====================
export interface ScanHistoryItem {
  id: string;
  timestamp: string;
  modality: ForensicModality;
  titleSnippet: string;
  overallAiProbability: number;
  verdict: string;
  extraMeta?: string;
  textResult?: AnalysisResult;
  imageResult?: ImageAnalysisResult;
  audioResult?: AudioAnalysisResult;
  docResult?: DocumentAnalysisResult;
}
